import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import coffeeIcon from '../assets/coffee-icon.jpg';
 
const styles = {
  header: {
    backgroundColor: '#4a2c1a',
    color: 'white',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 20px',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  icon: {
    width: '40px',
    height: '40px',
    marginRight: '10px',
  },
  title: {
    fontWeight: 'bold',
    fontSize: '20px',
    display: 'flex',
    alignItems: 'center',
  },
  navButtons: {
    display: 'flex',
    gap: '10px',
  },
  button: {
    backgroundColor: '#5a3e1a',
    border: 'none',
    borderRadius: '8px',
    color: 'white',
    fontWeight: 'bold',
    padding: '8px 12px',
    cursor: 'pointer',
  },
  container: {
    padding: '40px 20px',
    textAlign: 'center',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    minHeight: 'calc(100vh - 50px)', // Adjust height to fill viewport minus header height
    color: '#1f2d3d',
    overflowY: 'hidden',
    height: '100vh',
  },
  heading: {
    fontSize: '32px',
    fontWeight: 'bold',
    marginBottom: '20px',
  },
  content: {
    fontSize: '16px',
  },
  welcomeBox: {
    backgroundColor: "rgba(255, 255, 255, 0.8)",
    display: "inline-block",
    padding: "20px 40px",
    borderRadius: "15px",
    marginTop: "40px",
  },
  carouselContainer: {
    marginTop: '20px',
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderRadius: '15px',
    boxShadow: '0 4px 15px rgba(0,0,0,0.3)',
    padding: '20px',
    maxWidth: '600px',
    marginLeft: 'auto',
    marginRight: 'auto',
  },
  closeButton: {
    backgroundColor: '#4a2c1a',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    padding: '8px 12px',
    cursor: 'pointer',
    fontWeight: 'bold',
    float: 'right',
  },
};
 
function Home() {
  const navigate = useNavigate();
  const [showCarousel, setShowCarousel] = useState(false);
 
  const toggleCarousel = () => {
    setShowCarousel(!showCarousel);
  };
 
  return (
    <>
      <header style={styles.header}>
        <div style={styles.title}>
          <img src={coffeeIcon} alt="Coffee Icon" style={styles.icon} />
          CoffeeHub Control Center
        </div>
        <nav style={styles.navButtons}>
          <button style={styles.button} onClick={toggleCarousel}>About</button>
          <button style={styles.button} onClick={() => navigate('/login')}>Sign In</button>
        </nav>
      </header>
      <main style={styles.container}>
        <div style={styles.welcomeBox}>
          <h1 style={styles.heading}>Welcome to the Coffee Vending Monitoring World!</h1>
        </div>
        {showCarousel && (
          <div style={styles.carouselContainer}>
            <button style={styles.closeButton} onClick={toggleCarousel}>Close</button>
            <h2>About Us</h2>
            <p style={{ textAlign: 'justify' }}>
              Welcome to our Coffee Vending Machine Monitoring System. We provide real-time insights into machine operations, 
              allowing you to monitor ingredient levels, temperature controls, and overall machine performance. 
              Our system helps maintain optimal functionality through comprehensive tracking of usage patterns 
              and operational metrics, ensuring your coffee machines operate at peak efficiency.
            </p>
          </div>
        )}
      </main>
    </>
  );
}
 
export default Home;