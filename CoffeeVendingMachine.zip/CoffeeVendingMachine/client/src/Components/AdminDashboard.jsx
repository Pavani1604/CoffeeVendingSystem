import React, { useState, useEffect } from 'react';
import axiosInstance from '../utils/axiosConfig';
import {
  Box,
  Container,
  Typography,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  Alert,
  Paper,
  Switch,
  FormControlLabel
} from '@mui/material';
import {
  ArrowBack,
  DeveloperBoard,
  CheckCircle,
  Cancel,
  Visibility,
  VisibilityOff
} from '@mui/icons-material';

function AdminDashboard({ branchId, onBack }) {
  const [machines, setMachines] = useState([]);
  const [showLogs, setShowLogs] = useState({});
  const [logs, setLogs] = useState({});
  const [error, setError] = useState("");
  const [showTemperatureLogs, setShowTemperatureLogs] = useState({});
  const [logType, setLogType] = useState({});

  useEffect(() => {
    const fetchMachines = async () => {
      try {
        const response = await axiosInstance.get(`/api/coffee-machines/branch/${branchId}`);
        setMachines(response.data);
      } catch (err) {
        setError("Failed to fetch machines");
      }
    };
    fetchMachines();
  }, [branchId]);

  useEffect(() => {
    const refreshInterval = setInterval(() => {
      Object.entries(showLogs).forEach(([machineId, isShowing]) => {
        if (isShowing) {
          fetchLogs(machineId);
        }
      });
    }, 5000); // Fixed comment: Refresh every 5 seconds

    return () => clearInterval(refreshInterval);
  }, [showLogs, logType]);

  const fetchLogs = async (machineId, isTemperature) => {
    try {
      const endpoint = isTemperature 
        ? `/api/iot/temperature/${machineId}`
        : `/api/iot/ingredients/${machineId}`; // Updated endpoint for ingredients

      const response = await axiosInstance.get(endpoint);
      console.log(`Fetching ${isTemperature ? 'temperature' : 'ingredients'} logs:`, response.data);

      // Process logs
      const processLogs = (logs) => {
        return Array.isArray(logs) ? logs : [];
      };

      setLogs(prev => ({
        ...prev,
        [machineId]: {
          temperatureLogs: isTemperature ? processLogs(response.data) : [],
          ingredientsLogs: !isTemperature ? processLogs(response.data) : []
        }
      }));
    } catch (error) {
      console.error('Error fetching logs:', error);
      setError(`Failed to fetch ${isTemperature ? 'temperature' : 'ingredients'} logs`);
    }
  };

  const handleToggleLogs = async (machineId) => {
    const newShowLogs = { ...showLogs, [machineId]: !showLogs[machineId] };
    setShowLogs(newShowLogs);
    
    if (newShowLogs[machineId]) {
      fetchLogs(machineId);
    }
  };

  const handleLogTypeChange = (machineId) => async (event) => {
    const isTemperature = event.target.checked;
    setLogType(prev => ({ ...prev, [machineId]: isTemperature }));
    if (showLogs[machineId]) {
      fetchLogs(machineId);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
        <Button
          variant="contained"
          color="primary"
          startIcon={<ArrowBack />}
          onClick={onBack}
          sx={{ mr: 2 }}
        >
          Back to Branches
        </Button>
        <Typography variant="h5" sx={{ flexGrow: 1, fontWeight: 'bold' }}>
    
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {machines.map((machine) => (
          <Card key={machine.coffeeMachineId} elevation={3}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <DeveloperBoard 
                    color="primary"
                    sx={{ fontSize: 28 }}
                  />
                  <Typography variant="h6">
                    Machine: {machine.machineCode}
                  </Typography>
                  <Chip
                    icon={machine.status === 'ACTIVE' ? <CheckCircle /> : <Cancel />}
                    label={machine.status}
                    color={machine.status === 'ACTIVE' ? 'success' : 'error'}
                    variant="outlined"
                    sx={{ ml: 2 }}
                  />
                </Box>

                <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                  {showLogs[machine.coffeeMachineId] && (
                    <FormControlLabel
                      control={
                        <Switch
                          checked={logType[machine.coffeeMachineId] || false}
                          onChange={handleLogTypeChange(machine.coffeeMachineId)}
                          color="primary"
                        />
                      }
                      label={logType[machine.coffeeMachineId] ? "Temperature Logs" : "Ingredients Logs"}
                    />
                  )}
                  <Button
                    variant="contained"
                    color={showLogs[machine.coffeeMachineId] ? "error" : "primary"}
                    startIcon={showLogs[machine.coffeeMachineId] ? <VisibilityOff /> : <Visibility />}
                    onClick={() => handleToggleLogs(machine.coffeeMachineId)}
                    sx={{
                      transition: 'all 0.3s',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: 2,
                      }
                    }}
                  >
                    {showLogs[machine.coffeeMachineId] ? 'Hide Logs' : 'View Logs'}
                  </Button>
                </Box>
              </Box>

              {showLogs[machine.coffeeMachineId] && logs[machine.coffeeMachineId] && (
                <Box sx={{ mt: 2 }}>
                  <Divider sx={{ mb: 2 }} />
                  <LogsDisplay logs={logs[machine.coffeeMachineId]} />
                </Box>
              )}
            </CardContent>
          </Card>
        ))}
      </Box>
    </Container>
  );
}

export default AdminDashboard;