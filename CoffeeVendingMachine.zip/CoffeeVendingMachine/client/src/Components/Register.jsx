 
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "../utils/axiosConfig";
import { saveUserData } from "../utils/storage";
 
const styles = {
  background: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#a18676",
    backgroundImage:
      "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  container: {
    display: "flex",
    width: "700px",
    height: "450px",
    borderRadius: "20px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
    overflow: "hidden",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  },
  leftPanel: {
    flex: 1,
    backgroundColor: "#d9bba0",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    color: "#4a2c1a",
    padding: "40px 30px",
    backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  signInButton: {
    marginTop: "20px",
    padding: "10px 25px",
    border: "2px solid #4a2c1a",
    borderRadius: "10px",
    backgroundColor: "transparent",
    color: "#4a2c1a",
    fontWeight: "bold",
    cursor: "pointer",
    fontSize: "16px",
  },
  rightPanel: {
    flex: 1,
    backgroundColor: "#f3e9e1",
    padding: "40px 30px",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    borderTopRightRadius: "20px",
    borderBottomRightRadius: "20px",
  },
  title: {
    fontWeight: "bold",
    fontSize: "24px",
    color: "#4a2c1a",
    marginBottom: "25px",
  },
  input: {
    width: "90%",
    padding: "12px 15px",
    marginBottom: "15px",
    borderRadius: "10px",
    border: "none",
    backgroundColor: "#d9bba0",
    color: "#4a2c1a",
    fontSize: "14px",
  },
  button: {
    width: "100%",
    padding: "12px",
    borderRadius: "10px",
    border: "none",
    backgroundColor: "#4a2c1a",
    color: "#f3e9e1",
    fontWeight: "bold",
    fontSize: "16px",
    cursor: "pointer",
  },
  error: {
    color: "red",
    marginTop: "10px",
  },
};
 
function Register() {
  const navigate = useNavigate();
  const [register, setRegister] = useState({
    name: "",
    email: "",
    password: "",
    role: "",
  });
  const [error, setError] = useState("");
 
  const handleChange = (e) => {
    setRegister({
      ...register,
      [e.target.name]: e.target.value,
    });
  };
 
  const validateName = (name) => {
    const nameRegex = /^[A-Za-z\s]+$/; // Only alphabetic characters and spaces
    return nameRegex.test(name);
  };
 
  const validateEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@(gmail\.com|cognizant\.com)$/; // Gmail or Cognizant domains
    return emailRegex.test(email);
  };
 
  const validatePassword = (password) => {
    const strongPasswordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/; // Strong password
    return strongPasswordRegex.test(password);
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
 
    // Validate fields
    if (!register.name || !register.email || !register.password || !register.role) {
      setError("All fields are required");
      return;
    }
 
    if (!validateName(register.name)) {
      setError("Name must contain only alphabetic characters");
      return;
    }
 
    if (!validateEmail(register.email)) {
      setError("Email must be a valid Gmail or Cognizant address");
      return;
    }
 
    if (!validatePassword(register.password)) {
      setError(
        "Password must be at least 8 characters long and include uppercase, lowercase, number, and special character"
      );
      return;
    }
 
    try {
      const payload = {
        name: register.name,
        email: register.email,
        password: register.password,
        role: register.role.toUpperCase(),
      };
 
      console.log("Sending registration data:", payload);
 
      const response = await axios.post("/api/auth/register", payload, {
        headers: {
          "Content-Type": "application/json",
        },
      });
 
      if (response.data) {
        const userData = {
          name: register.name,
          email: register.email,
          role: register.role.toUpperCase(),
        };
        saveUserData(userData);
 
        alert("Registration successful!");
        navigate("/login");
      }
    } catch (error) {
      console.error("Registration Error Details:", {
        status: error.response?.status,
        message: error.response?.data?.message,
        data: error.response?.data,
      });
      setError(error.response?.data?.message || "Registration failed. Please contact support.");
    }
  };
 
  return (
    <div style={styles.background}>
      <div style={styles.container}>
        <div style={styles.leftPanel}>
        </div>
        <div style={styles.rightPanel}>
          <h2 style={{...styles.title, textAlign: "center"}}>Create Account</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Name"
              value={register.name}
              onChange={handleChange}
              required
              style={styles.input}
            />
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={register.email}
              onChange={handleChange}
              required
              style={styles.input}
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={register.password}
              onChange={handleChange}
              required
              style={styles.input}
            />
            <select
              name="role"
              value={register.role}
              onChange={handleChange}
              required
              style={{...styles.input, width: "100%"}}
            >
              <option value="" disabled>
                Role
              </option>
              <option value="technician">Technician</option>
              <option value="admin">Admin</option>
            </select>
            <button type="submit" style={{...styles.button, width: "90%", margin: "0 auto", display: "block"}}>
              SIGN UP
            </button>
          </form>
          <div style={{marginTop: "5px", textAlign: "center", color: "#4a2c1a"}}>
            <p>Already have an account?</p>
            <button style={{...styles.signInButton, margin: "0 auto", display: "block"}} onClick={() => navigate("/login")}>
              SIGN IN
            </button>
          </div>
          {error && <div style={styles.error}>{error}</div>}
        </div>
      </div>
    </div>
  );
}
 
export default Register;