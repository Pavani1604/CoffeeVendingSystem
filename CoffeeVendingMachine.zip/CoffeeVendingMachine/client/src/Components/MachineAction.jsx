import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axiosConfig";
import LogsDisplay from './LogsDisplay';
import {
  Box,
  Container,
  Typography,
  Button,
  Card,
  CardContent,
  Chip,
  Divider,
  Alert,
  Paper,
  Switch,
  FormControlLabel
} from '@mui/material';
import {
  ArrowBack,
  DeveloperBoard,
  CheckCircle,
  Cancel,
  Visibility,
  VisibilityOff
} from '@mui/icons-material';
 
function MachineAction({ branchId, onBack }) {
  const [machines, setMachines] = useState([]);
  const [showLogs, setShowLogs] = useState({});
  const [logs, setLogs] = useState({});
  const [error, setError] = useState("");
  const [showTemperatureLogs, setShowTemperatureLogs] = useState({});
  const [logType, setLogType] = useState({});
 
  useEffect(() => {
    const fetchMachines = async () => {
      try {
        const response = await axiosInstance.get("/api/coffee-machines/branch/" + branchId);
        setMachines(response.data);
      } catch (err) {
        setError("Failed to fetch machines");
      }
    };
    fetchMachines();
  }, [branchId]);
 
  useEffect(() => {
    const refreshInterval = setInterval(() => {
      Object.entries(showLogs).forEach(([machineId, isShowing]) => {
        if (isShowing) {
          fetchLogs(machineId);
        }
      });
    }, 5000); // Refresh every 5 seconds
 
    return () => clearInterval(refreshInterval);
  }, [showLogs, logType]);
 
  const fetchLogs = async (machineId) => {
    try {
      const isTemperature = logType[machineId] || false;
      const endpoint = isTemperature
        ? "/api/iot/temperature/" + machineId
        : "/api/iot/ingredients/" + machineId;
 
      const response = await axiosInstance.get(endpoint);
      console.log((isTemperature ? 'Temperature' : 'Ingredients') + " logs:", response.data);
 
      setLogs(prev => ({
        ...prev,
        [machineId]: {
          temperatureLogs: isTemperature ? response.data : [],
          ingredientsLogs: !isTemperature ? response.data : []
        }
      }));
    } catch (error) {
      console.error('Error fetching logs:', error);
      setError("Failed to fetch " + (logType[machineId] ? 'temperature' : 'ingredients') + " logs");
    }
  };
 
  const handleToggleLogs = async (machineId) => {
    const newShowLogs = { ...showLogs, [machineId]: !showLogs[machineId] };
    setShowLogs(newShowLogs);
   
    if (newShowLogs[machineId]) {
      fetchLogs(machineId);
    }
  };
 
  const handleLogTypeChange = (machineId) => async (event) => {
    const isTemperature = event.target.checked;
    setLogType(prev => ({ ...prev, [machineId]: isTemperature }));
    if (showLogs[machineId]) {
      fetchLogs(machineId);
    }
  };
 
  return (
    <Box sx={{
      minHeight: '100vh',
      position: 'relative',
      pt: 0,
    }}>
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundColor: "#a18676",
          backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
          opacity: 0.6,
          zIndex: -1,
        }}
      />
      <Container
        maxWidth="lg"
        sx={{
          py: 4,
          minHeight: '100vh',
          position: 'relative',
          zIndex: 2,
        }}
      >
        <Button
          variant="contained"
          sx={{ backgroundColor: '#4a2c1a', mb: 4, '&:hover': { backgroundColor: '#3a2415' } }}
          startIcon={<ArrowBack />}
          onClick={onBack}
        >
          Back to Branches
        </Button>
 
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
 
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          {machines.map((machine) => (
            <Card key={machine.coffeeMachineId} elevation={3}>
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <DeveloperBoard
                      color="#4a2c1a"
                      sx={{ fontSize: 28 }}
                    />
                    <Typography variant="h6">
                      Machine: {machine.machineCode}
                    </Typography>
                    <Chip
                      icon={machine.status === 'ACTIVE' ? <CheckCircle /> : <Cancel />}
                      label={machine.status}
                      color={machine.status === 'ACTIVE' ? 'success' : 'error'}
                      variant="outlined"
                      sx={{ ml: 2 }}
                    />
                  </Box>
 
                  <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                    {showLogs[machine.coffeeMachineId] && (
                      <FormControlLabel
                        control={
                          <Switch
                            checked={logType[machine.coffeeMachineId] || false}
                            onChange={handleLogTypeChange(machine.coffeeMachineId)}
                            color="#4a2c1a"
                          />
                        }
                        label={logType[machine.coffeeMachineId] ? "Temperature Logs" : "Ingredients Logs"}
                      />
                    )}
                    <Button
                      variant="contained"
                      sx={{ backgroundColor: '#4a2c1a', '&:hover': { backgroundColor: '#3a2415' }, transition: 'all 0.3s' }}
                      startIcon={showLogs[machine.coffeeMachineId] ? <VisibilityOff /> : <Visibility />}
                      onClick={() => handleToggleLogs(machine.coffeeMachineId)}
                    >
                      {showLogs[machine.coffeeMachineId] ? 'Hide Logs' : 'View Logs'}
                    </Button>
                  </Box>
                </Box>
 
                {showLogs[machine.coffeeMachineId] && logs[machine.coffeeMachineId] && (
                  <Box sx={{ mt: 2 }}>
                    <Divider sx={{ mb: 2 }} />
                    <LogsDisplay logs={logs[machine.coffeeMachineId]} />
                  </Box>
                )}
              </CardContent>
            </Card>
          ))}
        </Box>
      </Container>
    </Box>
  );
}
 
export default MachineAction;
