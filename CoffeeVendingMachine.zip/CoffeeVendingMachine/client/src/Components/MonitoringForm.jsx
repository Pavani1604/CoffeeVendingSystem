import React, { useState, useEffect } from 'react';
import { sendTemperatureData, sendIngredientsData, updateMachine } from '../utils/MonitoringService';
import axiosInstance from '../utils/axiosConfig';

const styles = {
  container: {
    maxWidth: "600px",
    margin: "0 auto",
    padding: "20px",
    backgroundColor: "#f9f9f9",
    borderRadius: "10px",
    boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
  },
  formGroup: {
    marginBottom: "15px",
  },
  label: {
    display: "block",
    fontWeight: "bold",
    marginBottom: "5px",
  },
  input: {
    width: "100%",
    padding: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
  },
  button: {
    padding: "10px 20px",
    backgroundColor: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
  },
};

const MonitoringForm = ({ coffeeMachineId, formType, onClose }) => {
  const [formData, setFormData] = useState({
    temperature: '',
    temperatureUnit: 'celsius',
    waterLevel: '',
    coffeePowder: '',
    milkLevel: '',
    teaPowder: '',
    sugarLevel: '',
    recordedAt: new Date().toISOString()
  });

  useEffect(() => {
    console.log('MonitoringForm received coffeeMachineId:', coffeeMachineId);
  }, [coffeeMachineId]);

  const validateTemperature = () => {
    if (!coffeeMachineId) {
      throw new Error('No coffee machine selected');
    }

    // Validate temperature (between -50 and 150 Celsius)
    let tempInCelsius = parseFloat(formData.temperature);
    if (formData.temperatureUnit === 'kelvin') {
      tempInCelsius = tempInCelsius - 273.15;
    }
    if (isNaN(tempInCelsius) || tempInCelsius < -50 || tempInCelsius > 150) {
      throw new Error('Temperature must be between -50°C and 150°C');
    }

    return { tempInCelsius };
  };

  const validateIngredients = () => {
    if (!coffeeMachineId) {
      throw new Error('No coffee machine selected');
    }

    // Validate levels (between 0 and 100)
    ['waterLevel', 'coffeePowder', 'milkLevel', 'teaPowder', 'sugarLevel'].forEach(field => {
      const value = parseFloat(formData[field]);
      if (isNaN(value) || value < 0 || value > 100) {
        throw new Error(`${field} must be between 0 and 100`);
      }
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      if (formType === 'temperature') {
        const { tempInCelsius } = validateTemperature();
        await sendTemperatureData({
          temperature: tempInCelsius,
          coffeeMachineId: coffeeMachineId,
          recordedAt: formData.recordedAt
        });
      } else {
        validateIngredients();
        await sendIngredientsData({
          coffeeMachineId: coffeeMachineId,
          waterLevel: formData.waterLevel,
          coffeePowder: formData.coffeePowder,
          milkLevel: formData.milkLevel,
          teaPowder: formData.teaPowder,
          sugarLevel: formData.sugarLevel,
          recordedAt: formData.recordedAt
        });
      }
      
      alert('Data sent successfully!');
      onClose();
    } catch (error) {
      console.error('Error:', error);
      alert(error.message || 'An error occurred. Please try again.');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div style={styles.container}>
      <h2 className="text-2xl font-bold mb-4">
        {formType === 'temperature' ? 'Temperature Form' : 'Ingredients Form'}
      </h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        {formType === 'temperature' ? (
          <div className="form-group" style={styles.formGroup}>
            <label className="block mb-1" style={styles.label}>Temperature:</label>
            <div style={{ display: 'flex', gap: '1rem' }}>
              <input
                type="number"
                name="temperature"
                value={formData.temperature}
                onChange={handleChange}
                className="form-control border p-2"
                style={{ ...styles.input, width: '70%' }}
                required
              />
              <select
                name="temperatureUnit"
                value={formData.temperatureUnit}
                onChange={handleChange}
                className="form-control border p-2"
                style={{ ...styles.input, width: '30%' }}
              >
                <option value="celsius">°C</option>
                <option value="kelvin">K</option>
              </select>
            </div>
          </div>
        ) : (
          <>
            <div className="form-group" style={styles.formGroup}>
              <label className="block mb-1" style={styles.label}>Water Level (%):</label>
              <input
                type="number"
                name="waterLevel"
                value={formData.waterLevel}
                onChange={handleChange}
                min="0"
                max="100"
                className="form-control border p-2 w-full"
                style={styles.input}
                required
              />
            </div>

            <div className="form-group" style={styles.formGroup}>
              <label className="block mb-1" style={styles.label}>Coffee Powder (%):</label>
              <input
                type="number"
                name="coffeePowder"
                value={formData.coffeePowder}
                onChange={handleChange}
                min="0"
                max="100"
                className="form-control border p-2 w-full"
                style={styles.input}
                required
              />
            </div>

            <div className="form-group" style={styles.formGroup}>
              <label className="block mb-1" style={styles.label}>Milk Level (%):</label>
              <input
                type="number"
                name="milkLevel"
                value={formData.milkLevel}
                onChange={handleChange}
                min="0"
                max="100"
                className="form-control border p-2 w-full"
                style={styles.input}
                required
              />
            </div>

            <div className="form-group" style={styles.formGroup}>
              <label className="block mb-1" style={styles.label}>Tea Powder (%):</label>
              <input
                type="number"
                name="teaPowder"
                value={formData.teaPowder}
                onChange={handleChange}
                min="0"
                max="100"
                className="form-control border p-2 w-full"
                style={styles.input}
                required
              />
            </div>

            <div className="form-group" style={styles.formGroup}>
              <label className="block mb-1" style={styles.label}>Sugar Level (%):</label>
              <input
                type="number"
                name="sugarLevel"
                value={formData.sugarLevel}
                onChange={handleChange}
                min="0"
                max="100"
                className="form-control border p-2 w-full"
                style={styles.input}
                required
              />
            </div>
          </>
        )}

        <button type="submit" style={styles.button}>
          Submit Data
        </button>
      </form>
    </div>
  );
};

export default MonitoringForm;
