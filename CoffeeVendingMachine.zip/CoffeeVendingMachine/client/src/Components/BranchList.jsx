import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  Container,
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Button,
  Paper,
  Divider,
  AppBar,
  Toolbar,
  IconButton,
} from '@mui/material';
import {
  Business,
  ArrowBack,
  Store,
  Menu as MenuIcon,
  Logout as LogoutIcon,
} from '@mui/icons-material';
import TechnicianIcon from '../assets/Technician.jfif';
 
function BranchList({ locationId, onSelectBranch, onBack }) {
  const [branches, setBranches] = useState([]);
  const [selected, setSelected] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
 
  useEffect(() => {
    const fetchBranches = async () => {
      try {
        const response = await axios.get(
          `http://localhost:8082/api/branches/location/${locationId}`
        );
        setBranches(response.data);
        setError("");
      } catch (err) {
        setError("Failed to fetch branches. Please try again.");
      }
    };
    fetchBranches();
  }, [locationId]);
 
  const handleLogout = () => {
    localStorage.removeItem('authUser');
    navigate('/login');
  };
 
  const handleChange = (e) => {
    setSelected(e.target.value);
    const branch = branches.find((b) => b.id === Number(e.target.value));
    onSelectBranch(branch);
  };
 
  return (
    <Box sx={{
      minHeight: '100vh',
      position: 'relative',
      pt: 0,
    }}>
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
          opacity: 0.6,
          zIndex: -1,
        }}
      />
      <AppBar position="fixed" sx={{ backgroundColor: '#4a2c1a', top: 0, zIndex: 10 }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <img src={TechnicianIcon} alt="Technician Icon" style={{ width: 40, height: 40, marginRight: 10, borderRadius: 4 }} />
          </Box>
          {/* Removed Technician Dashboard text */}
          <IconButton color="inherit" onClick={handleLogout}>
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
 
      <Container maxWidth="md" sx={{ pt: 10, zIndex: 2, position: 'relative' }}>
        <Box sx={{ my: 4 }}>
          <Button
            variant="contained"
            startIcon={<ArrowBack />}
            onClick={onBack}
            sx={{ mb: 3, backgroundColor: '#4a2c1a', '&:hover': { backgroundColor: '#3a2415' } }}
          >
            Back to Locations
          </Button>
 
          <Paper elevation={5} sx={{ p: 4, backgroundColor: 'rgba(255,255,255,0.9)', borderRadius: 2, backdropFilter: 'blur(10px)' }}>
            <Typography variant="h5" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
              <Business color="d9bba0" />
              Available Branches
            </Typography>
 
            <Divider sx={{ mb: 2 }} />
 
            {error && (
              <Typography color="error" sx={{ mb: 2 }}>
                {error}
              </Typography>
            )}
 
            <List>
              {branches.map(branch => (
                <ListItem
                  key={branch.id}
                  disablePadding
                  sx={{ mb: 1, bgcolor: 'background.paper', borderRadius: 1 }}
                >
                  <ListItemButton
                    onClick={() => onSelectBranch(branch)}
                    sx={{
                      '&:hover': {
                        bgcolor: '#d9bba0',
                        '& .MuiListItemIcon-root': { color: 'primary.contrastText' },
                        '& .MuiListItemText-primary': { color: 'primary.contrastText' }
                      }
                    }}
                  >
                    <ListItemIcon>
                      <Store color="#d9bba0" />
                    </ListItemIcon>
                    <ListItemText
                      primary={branch.name}
                      secondary={branch.address}
                    />
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          </Paper>
        </Box>
      </Container>
    </Box>
  );
}
 
export default BranchList;
 