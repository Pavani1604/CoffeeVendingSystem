import React from 'react'

const Admin = () => {
  return (
    <div>
      hlo this is admin...
    </div>
  )
}

export default Admin
