import React, { useState } from 'react';
import axiosInstance from '../utils/axiosConfig';
import {
  Paper,
  Typography,
  TextField,
  Button,
  Box,
  Stack,
  Grid,
  InputAdornment
} from '@mui/material';
import {
  Coffee,
  Save,
  Cancel as CancelIcon,
  WaterDrop,
  LocalDrink,
  EmojiFoodBeverage,
  Cookie
} from '@mui/icons-material';
 
const IngredientsForm = ({ machineId, onClose }) => {
  const [formData, setFormData] = useState({
    waterLevel: '',
    coffeePowder: '',
    milkLevel: '',
    teaPowder: '',
    sugarLevel: '',
    type:''
  });
 
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const payload = {
        ...formData,
        coffeeMachineId: machineId,
        //recordedAt: new Date().toISOString()  // Add explicit timestamp
      };

      await axiosInstance.post('/api/iot/ingredients', payload);
      alert('Ingredients data saved successfully');
      onClose();
    } catch (error) {
      console.error('Error saving ingredients:', error);
      alert('Error saving ingredients data');
    }
  };
 
  const ingredientFields = [
    { name: 'waterLevel', label: 'Water Level', icon: <WaterDrop /> },
    { name: 'coffeePowder', label: 'Coffee Powder', icon: <Coffee /> },
    { name: 'milkLevel', label: 'Milk Level', icon: <LocalDrink /> },
    { name: 'teaPowder', label: 'Tea Powder', icon: <EmojiFoodBeverage /> },
    { name: 'sugarLevel', label: 'Sugar Level', icon: <Cookie /> },
  ];
 
  return (
    <Paper elevation={3} sx={{ p: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Coffee color="#4a2c1a" />
        Ingredients Data
      </Typography>
 
      <form onSubmit={handleSubmit}>
        <Stack spacing={3}>
          <Grid container spacing={2}>
            {ingredientFields.map((field) => (
              <Grid item xs={12} sm={6} key={field.name}>
                <TextField
                  label={field.label}
                  type="number"
                  name={field.name}
                  value={formData[field.name]}
                  onChange={handleChange}
                  required
                  fullWidth
                  variant="outlined"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        {field.icon}
                      </InputAdornment>
                    ),
                    endAdornment: <InputAdornment position="end">%</InputAdornment>
                  }}
                  inputProps={{
                    min: 0,
                    max: 100
                  }}
                />
              </Grid>
            ))}
          </Grid>
 
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
            <Button
              variant="contained"
              color="#4a2c1a"
              type="submit"
              startIcon={<Save />}
            >
              Save
            </Button>
            <Button
              variant="outlined"
              color="error"
              onClick={onClose}
              startIcon={<CancelIcon />}
            >
              Cancel
            </Button>
          </Box>
        </Stack>
      </form>
    </Paper>
  );
};
 
export default IngredientsForm;

