import React, { useState } from 'react';
import axiosInstance from '../utils/axiosConfig';
import {
  Paper,
  Typography,
  TextField,
  Button,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Box,
  Stack
} from '@mui/material';
import {
  ThermostatAuto,
  Save,
  Cancel as CancelIcon
} from '@mui/icons-material';
 
const TemperatureForm = ({ machineId, onClose }) => {
  const [temperature, setTemperature] = useState('');
  const [type, setType] = useState('celsius');
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Get auth token from localStorage
      const userData = localStorage.getItem('authUser');
      const token = userData ? JSON.parse(userData).token : null;
 
      if (!token) {
        throw new Error('Authentication token not found');
      }
 
      const payload = {
        temperature: parseFloat(temperature),
        type: type,
        coffeeMachineId: machineId
      };
     
      console.log('Sending temperature payload:', payload);
     
      const response = await axiosInstance.post('/api/iot/temperature', payload, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
     
      console.log('Temperature response:', response.data);
     
      if (response.data) {
        alert('Temperature data saved successfully');
        onClose();
      }
    } catch (error) {
      console.error('Error details:', error.response || error);
      alert(`Error saving temperature data: ${error?.response?.data?.message || error.message}`);
    }
  };
 
  return (
    <Paper elevation={3} sx={{ p: 3, borderRadius: 2 }}>
      <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <ThermostatAuto color="primary" />
        Temperature Data
      </Typography>
     
      <form onSubmit={handleSubmit}>
        <Stack spacing={3}>
          <TextField
            label="Temperature"
            type="number"
            value={temperature}
            onChange={(e) => setTemperature(e.target.value)}
            required
            fullWidth
            variant="outlined"
            InputProps={{
              endAdornment: <Typography variant="subtitle2">°C</Typography>
            }}
          />
 
          <FormControl fullWidth>
            <InputLabel>Type</InputLabel>
            <Select
              value={type}
              onChange={(e) => setType(e.target.value)}
              label="Type"
            >
              <MenuItem value="celsius">Celsius</MenuItem>
              <MenuItem value="kelvin">Kelvin</MenuItem>
            </Select>
          </FormControl>
 
          <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
            <Button
              variant="contained"
              color="primary"
              type="submit"
              startIcon={<Save />}
            >
              Save
            </Button>
            <Button
              variant="outlined"
              color="error"
              onClick={onClose}
              startIcon={<CancelIcon />}
            >
              Cancel
            </Button>
          </Box>
        </Stack>
      </form>
    </Paper>
  );
};
 
export default TemperatureForm;
 
 