import React from "react";

const styles = {
  overlay: {
    position: "fixed",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(0,0,0,0.5)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000,
  },
  container: {
    backgroundColor: "white",
    padding: "20px",
    borderRadius: "10px",
    width: "400px",
    boxShadow: "0 4px 8px rgba(0,0,0,0.2)",
  },
  label: {
    fontWeight: "bold",
    marginBottom: "5px",
  },
  input: {
    width: "100%",
    padding: "8px",
    marginBottom: "10px",
    borderRadius: "5px",
    border: "1px solid #ccc",
  },
  button: {
    padding: "10px 20px",
    backgroundColor: "#4CAF50",
    color: "white",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
  },
};

function IngredientsPreview({ ingredients, onClose }) {
  if (!ingredients) return null;

  return (
    <div style={styles.overlay}>
      <div style={styles.container}>
        <h3>Ingredients Preview</h3>
        {Object.keys(ingredients).map((key) => (
          <div key={key}>
            <label style={styles.label}>{key}:</label>
            <input
              type="text"
              value={ingredients[key]}
              readOnly
              style={styles.input}
            />
          </div>
        ))}
        <button onClick={onClose} style={styles.button}>
          Close
        </button>
      </div>
    </div>
  );
}

export default IngredientsPreview;