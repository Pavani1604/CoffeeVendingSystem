import React, { useState } from "react";
import axios from '../utils/axiosConfig';
import { useNavigate } from "react-router-dom";
import { saveUserData } from '../utils/storage';
 
const styles = {
  background: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#a18676",
    backgroundImage:
      "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
    position: "relative",
    overflow: "hidden",
  },
  backButton: {
    position: "absolute",
    top: "20px",
    left: "20px",
    backgroundColor: "#d9bba0",
    color: "#4a2c1a",
    border: "none",
    borderRadius: "10px",
    padding: "10px 15px",
    fontWeight: "bold",
    cursor: "pointer",
    boxShadow: "0 2px 5px rgba(0,0,0,0.2)",
  },
  container: {
    width: "700px",
    height: "450px",
    display: "flex",
    borderRadius: "20px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.3)",
    overflow: "hidden",
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    color: "#4a2c1a",
    backgroundColor: "#f3e9e1",
  },
  leftPanel: {
    flex: 1,
    backgroundColor: "#f3e9e1",
    padding: "40px 30px",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
  },
  rightPanel: {
    flex: 1,
    backgroundColor: "#d9bba0",
    padding: "40px 30px",
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  title: {
    fontWeight: "bold",
    fontSize: "24px",
    marginBottom: "25px",
  },
  input: {
    width: "90%",
    padding: "12px 15px",
    marginBottom: "15px",
    borderRadius: "10px",
    border: "none",
    backgroundColor: "#d9bba0",
    color: "#4a2c1a",
    fontSize: "14px",
  },
  button: {
    width: "150px",
    padding: "12px",
    borderRadius: "10px",
    border: "none",
    backgroundColor: "#4a2c1a",
    color: "#f3e9e1",
    fontWeight: "bold",
    fontSize: "16px",
    cursor: "pointer",
    marginTop: "10px",
  },
  signUpButton: {
    width: "150px",
    padding: "12px",
    borderRadius: "10px",
    border: "2px solid #4a2c1a",
    backgroundColor: "transparent",
    color: "#4a2c1a",
    fontWeight: "bold",
    fontSize: "16px",
    cursor: "pointer",
    marginTop: "15px",
  },
  signUpText: {
    fontSize: "16px",
    marginBottom: "10px",
  },
};
 
function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const navigate = useNavigate();
 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
 
  const handleSubmit = async (e) => {
    e.preventDefault();
 
    if (!formData.email || !formData.password) {
      alert("Email and password are required");
      return;
    }
 
    try {
      const response = await axios({
        method: 'POST',
        url: '/api/auth/login',
        data: {
          email: formData.email,
          password: formData.password
        }
      });
 
      if (response.data) {
        const userData = {
          token: response.data.token,
          name: response.data.name,
          email: formData.email,
          role: response.data.role
        };
 
        saveUserData(userData);
        console.log('Login successful:', userData);
 
        const role = userData.role?.toLowerCase();
        switch(role) {
          case "admin":
            navigate("/admin");
            break;
          case "technician":
            navigate("/technician");
            break;
          default:
            navigate("/dashboard");
        }
      }
    } catch (error) {
      const errorMessage = error.response?.data?.message || "Login failed";
      console.error('Login Error:', errorMessage);
      alert(errorMessage);
    }
  };
 
  const redirectToRegister = () => {
    navigate('/register');
  };
 
  const backToHome = () => {
    navigate('/');
  };
 
  return (
    <div style={styles.background}>
      <button style={styles.backButton} onClick={backToHome}>Back to Home</button>
      <div style={styles.container}>
        <div style={styles.leftPanel}>
          <h2 style={{...styles.title, textAlign: "center"}}>Sign In</h2>
          <form onSubmit={handleSubmit} style={{display: "flex", flexDirection: "column", gap: "10px"}}>
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={formData.email}
              onChange={handleChange}
              required
              style={styles.input}
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleChange}
              required
              style={styles.input}
            />
            <button type="submit" style={{...styles.button, margin: "0 auto", display: "block", width: "90%"}}>SIGN IN</button>
          </form>
          <div style={{...styles.signUpText, textAlign: "center", marginTop: "15px"}}>Don't have an account?</div>
          <button onClick={redirectToRegister} style={{...styles.signUpButton, margin: "10px auto 0 auto", display: "block"}}>SIGN UP</button>
        </div>
        <div style={styles.rightPanel}>
        </div>
      </div>
    </div>
  );
}
 
export default Login;