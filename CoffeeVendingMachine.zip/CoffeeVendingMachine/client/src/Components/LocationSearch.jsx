import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import {
  Container,
  Box,
  TextField,
  Typography,
  List,
  AppBar,
  Toolbar,
  IconButton,
  Paper,
  InputAdornment,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import {
  LocationOn,
  Search as SearchIcon,
  Menu as MenuIcon,
  Logout as LogoutIcon,
} from '@mui/icons-material';
import TechnicianIcon from '../assets/Technician.jfif';
 
function LocationSearch({ onSelectLocation }) {
  const [locations, setLocations] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
 
  useEffect(() => {
    axios
      .get("http://localhost:8082/api/locations")
      .then((res) => setLocations(res.data))
      .catch(() => alert("Failed to fetch locations"));
  }, []);
 
  const handleLogout = () => {
    localStorage.removeItem('authUser');
    navigate('/login');
  };
 
  return (
    <Box sx={{
      minHeight: '100vh',
      position: 'relative',
      pt: 0,
    }}>
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
          opacity: 0.6,
          zIndex: -1,
        }}
      />
      <AppBar position="fixed" sx={{ backgroundColor: '#4a2c1a', top: 0, zIndex: 10 }}>
        <Toolbar sx={{ justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <img src={TechnicianIcon} alt="Technician Icon" style={{ width: 40, height: 40, marginRight: 10, borderRadius: 4 }} />
          </Box>
          {/* Removed Technician Dashboard text */}
          <IconButton color="inherit" onClick={handleLogout}>
            <LogoutIcon />
          </IconButton>
        </Toolbar>
      </AppBar>
 
      <Container maxWidth="md" sx={{ pt: 10, zIndex: 2, position: 'relative' }}>
        <Paper elevation={5} sx={{
          p: 4,
          backgroundColor: 'rgba(255,255,255,0.9)',
          borderRadius: 2,
          backdropFilter: 'blur(10px)'
        }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search locations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon sx={{ color: '#4a2c1a' }} />
                </InputAdornment>
              ),
            }}
            sx={{
              mb: 3,
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': {
                  borderColor: '#d9bba0',
                },
              }
            }}
          />
 
          <List sx={{
            bgcolor: 'background.paper',
            borderRadius: 1,
            overflow: 'hidden'
          }}>
            {locations
              .filter(location =>
                location.name.toLowerCase().includes(searchTerm.toLowerCase())
              )
              .map(location => (
                <ListItem
                  key={location.id}
                  disablePadding
                  sx={{ mb: 1 }}
                >
                  <ListItemButton
                    onClick={() => onSelectLocation(location)}
                    sx={{
                      py: 2,
                      transition: 'all 0.3s',
                      '&:hover': {
                        bgcolor: '#d9bba0',
                        transform: 'translateY(-2px)',
                        boxShadow: 1,
                        '& .MuiListItemIcon-root': { color: 'primary.contrastText' },
                        '& .MuiListItemText-primary': { color: 'primary.contrastText' }
                      },
                      '&.Mui-focusVisible': {
                        backgroundColor: 'transparent !important',
                      },
                      '&.Mui-selected': {
                        backgroundColor: 'transparent !important',
                      },
                      '&:focus': {
                        backgroundColor: 'transparent !important',
                      }
                    }}
                  >
                    <ListItemIcon>
                      <LocationOn sx={{ color: '#4a2c1a' }} />
                    </ListItemIcon>
                    <ListItemText
                      primary={location.name}
                      secondary={location.address}
                      primaryTypographyProps={{
                        fontWeight: 'medium'
                      }}
                    />
                  </ListItemButton>
                </ListItem>
              ))}
          </List>
        </Paper>
      </Container>
    </Box>
  );
}
 
export default LocationSearch;
 
 