import React from 'react';
import {
  Typography,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Box
} from '@mui/material';
import { format } from 'date-fns';

const LogsDisplay = ({ logs }) => {
  console.log('LogsDisplay received:', logs);
  const { temperatureLogs = [], ingredientsLogs = [] } = logs || {};

  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'N/A';
    try {
      // Force the timestamp to be a string if it's a Date object
      const dateStr = typeof timestamp === 'object' ? timestamp.toISOString() : timestamp;
      return new Date(dateStr).toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      });
    } catch (error) {
      console.error('Error formatting timestamp:', error, timestamp);
      return 'Invalid Date';
    }
  };

  return (
    <Box sx={{ mt: 3 }}>
      {Array.isArray(temperatureLogs) && temperatureLogs.length > 0 && (
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>Temperature History</Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Temperature</TableCell>
                  <TableCell>Type</TableCell>
                  <TableCell>Date & Time</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {temperatureLogs.map((temp, index) => (
                  <TableRow key={temp.tempId || index}>
                    <TableCell>{temp.temperature}</TableCell>
                    <TableCell>{temp.type || 'N/A'}</TableCell>
                    <TableCell>{formatTimestamp(temp.recordedAt)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {Array.isArray(ingredientsLogs) && ingredientsLogs.length > 0 && (
        <Box sx={{ mb: 4 }}>
          <Typography variant="h6" gutterBottom>Ingredients History</Typography>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Water (%)</TableCell>
                  <TableCell>Coffee (%)</TableCell>
                  <TableCell>Milk (%)</TableCell>
                  <TableCell>Tea (%)</TableCell>
                  <TableCell>Sugar (%)</TableCell>
                  <TableCell>Date & Time</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {ingredientsLogs.map((log, index) => (
                  <TableRow key={log.id || index}>
                    <TableCell>{log.waterLevel}</TableCell>
                    <TableCell>{log.coffeePowder}</TableCell>
                    <TableCell>{log.milkLevel}</TableCell>
                    <TableCell>{log.teaPowder}</TableCell>
                    <TableCell>{log.sugarLevel}</TableCell>
                    <TableCell>{formatTimestamp(log.recordedAt)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}

      {(!Array.isArray(temperatureLogs) || !temperatureLogs.length) && 
       (!Array.isArray(ingredientsLogs) || !ingredientsLogs.length) && (
        <Paper sx={{ p: 3, textAlign: 'center' }}>
          <Typography color="textSecondary">
            No logs available. Toggle switch to view different log types.
          </Typography>
        </Paper>
      )}
    </Box>
  );
};

export default LogsDisplay;
