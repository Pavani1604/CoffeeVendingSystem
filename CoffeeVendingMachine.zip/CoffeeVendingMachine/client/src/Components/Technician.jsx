import React from 'react'

const Technician = () => {

  const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedBranch, setSelectedBranch] = useState(null);

  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      {!selectedLocation ? (
        <LocationSearch onSelectLocation={setSelectedLocation} />
      ) : !selectedBranch ? (
        <BranchList
          locationId={selectedLocation.id}
          onSelectBranch={setSelectedBranch}
          onBack={() => setSelectedLocation(null)}
        />
      ) : (
        <MachineActionTechnician
          branchId={selectedBranch.id}
          onBack={() => setSelectedBranch(null)}
        />
      )}
    </div>
  );
};

export default Technician
