import React, { useState, useEffect } from "react";
import axiosInstance from "../utils/axiosConfig";
import TemperatureForm from './TemperatureForm';
import IngredientsForm from './IngredientsForm';
import LogsDisplay from './LogsDisplay';
import {
  Box,
  Container,
  Paper,
  Typography,
  Button,
  IconButton,
  Chip,
  Menu,
  MenuItem,
  Divider,
  Card,
  CardContent,
  FormControlLabel,
  Switch,
} from '@mui/material';
import {
  ArrowBack,
  Add as AddIcon,
  LocalDrink,
  Assessment,
  DeveloperBoard,
  CheckCircle,
  Cancel,
  ThermostatAuto,
  Coffee
} from '@mui/icons-material';
 
function MachineActionTechnician({ branchId, onBack }) {
  const [machines, setMachines] = useState([]);
  const [selectedMachine, setSelectedMachine] = useState(null);
  const [selectedForm, setSelectedForm] = useState(null);
  const [showLogs, setShowLogs] = useState({});
  const [logs, setLogs] = useState({});
  const [error, setError] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [logType, setLogType] = useState({});
 
  useEffect(() => {
    const fetchMachines = async () => {
      try {
        const response = await axiosInstance.get(`/api/coffee-machines/branch/${branchId}`);
        setMachines(response.data);
      } catch (err) {
        setError("Failed to fetch machines");
      }
    };
    fetchMachines();
  }, [branchId]);
 
  useEffect(() => {
    const refreshLogs = async () => {
      try {
        for (const machineId in showLogs) {
          if (showLogs[machineId]) {
            await fetchLogs(machineId, logType[machineId]);
          }
        }
      } catch (error) {
        console.error('Error refreshing logs:', error);
      }
    };
    refreshLogs();
  }, [showLogs, logType]);
 
  const fetchLogs = async (machineId, isTemperature) => {
    try {
      const endpoint = isTemperature
        ? `/api/iot/temperature/${machineId}`
        : `/api/iot/ingredients/${machineId}`; // Updated endpoint for ingredients
 
      const response = await axiosInstance.get(endpoint);
      console.log('Raw API Response:', response.data);
 
      const processLogs = (logs) => {
        return Array.isArray(logs) ? logs.map(log => ({
          ...log
        })) : [];
      };
 
      setLogs(prev => ({
        ...prev,
        [machineId]: {
          temperatureLogs: isTemperature ? processLogs(response.data) : [],
          ingredientsLogs: !isTemperature ? processLogs(response.data) : []
        }
      }));
    } catch (error) {
      console.error('Error fetching logs:', error);
      setError(`Failed to fetch ${isTemperature ? 'temperature' : 'ingredients'} logs`);
    }
  };
 
  const handleFormSelect = (machineId, formType) => {
    setSelectedMachine(machineId);
    setSelectedForm(formType);
  };
 
  const handleToggleLogs = async (machineId) => {
    const newShowLogs = { ...showLogs, [machineId]: !showLogs[machineId] };
    setShowLogs(newShowLogs);
   
    if (newShowLogs[machineId]) {
      // Initialize logType for this machine if it doesn't exist
      if (typeof logType[machineId] === 'undefined') {
        setLogType(prev => ({ ...prev, [machineId]: false }));
      }
      // Fetch logs based on current logType
      await fetchLogs(machineId, logType[machineId] || false);
    }
  };
 
  const handleLogTypeChange = (machineId) => async (event) => {
    const isTemperature = event.target.checked;
    console.log('Switching to:', isTemperature ? 'temperature' : 'ingredients', 'logs');
    setLogType(prev => ({ ...prev, [machineId]: isTemperature }));
    await fetchLogs(machineId, isTemperature);
  };
 
  const handleMenuClick = (event, machineId) => {
    setSelectedMachine(machineId);
    setAnchorEl(event.currentTarget);
  };
 
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
 
  return (
    <Box sx={{
      minHeight: '100vh',
      position: 'relative',
      pt: 0,
    }}>
      <Box
        sx={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundImage: "url('https://images.unsplash.com/photo-1509042239860-f550ce710b93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1470&q=80')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundAttachment: 'fixed',
          opacity: 0.6,
          zIndex: -1,
        }}
      />
      <Container
        maxWidth="lg"
        sx={{
          py: 4,
          minHeight: '100vh',
          position: 'relative',
          zIndex: 2,
        }}
      >
      <Button
        variant="contained"
        sx={{ backgroundColor: '#4a2c1a', '&:hover': { backgroundColor: '#3a2415' }, mb: 4 }}
        startIcon={<ArrowBack />}
        onClick={onBack}
      >
        Back to Branches
      </Button>
 
      {error && (
        <Typography color="error" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
 
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
        {machines.map((machine) => (
          <Card key={machine.coffeeMachineId} elevation={3}>
            <CardContent>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <DeveloperBoard color="#d9bba0" />
                  <Typography variant="h6">
                    {machine.machineCode}
                  </Typography>
                  <Chip
                    icon={machine.status === 'ACTIVE' ? <CheckCircle /> : <Cancel />}
                    label={machine.status}
                    color={machine.status === 'ACTIVE' ? 'success' : 'error'}
                    variant="outlined"
                  />
                </Box>
 
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <Button
                    variant="contained"
                    startIcon={<AddIcon />}
                    onClick={(e) => handleMenuClick(e, machine.coffeeMachineId)}
                    sx={{ backgroundColor: '#4a2c1a', '&:hover': { backgroundColor: '#3a2415' } }}
                  >
                    Add Data
                  </Button>
                  <Menu
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl) && selectedMachine === machine.coffeeMachineId}
                    onClose={handleMenuClose}
                  >
                    <MenuItem onClick={() => {
                      handleFormSelect(machine.coffeeMachineId, 'temperature');
                      handleMenuClose();
                    }}>
                      <ThermostatAuto sx={{ mr: 1 }} /> Temperature
                    </MenuItem>
                    <MenuItem onClick={() => {
                      handleFormSelect(machine.coffeeMachineId, 'ingredients');
                      handleMenuClose();
                    }}>
                      <Coffee sx={{ mr: 1 }} /> Ingredients
                    </MenuItem>
                  </Menu>
 
                  <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
                    {showLogs[machine.coffeeMachineId] && (
                      <FormControlLabel
                        control={
                          <Switch
                            checked={logType[machine.coffeeMachineId] || false}
                            onChange={handleLogTypeChange(machine.coffeeMachineId)}
                            color="#d9bba0"
                          />
                        }
                        label={
                          <Typography variant="body2" color="textSecondary">
                            {logType[machine.coffeeMachineId] ? "Temperature" : "Ingredients"}
                          </Typography>
                        }
                      />
                    )}
<Button
  variant="contained"
  sx={{ backgroundColor: '#f3e9e1', color: '#4a2c1a' }}
  startIcon={<Assessment />}
  onClick={() => handleToggleLogs(machine.coffeeMachineId)}
>
  {showLogs[machine.coffeeMachineId] ? 'Hide Logs' : 'Show Logs'}
</Button>
                  </Box>
                </Box>
              </Box>
 
              {/* Forms Section */}
              {selectedMachine === machine.coffeeMachineId && selectedForm && (
                <Paper elevation={2} sx={{ p: 2, mb: 2 }}>
                  {selectedForm === 'temperature' && (
                    <TemperatureForm
                      machineId={machine.coffeeMachineId}
                      onClose={() => {
                        setSelectedForm(null);
                        setSelectedMachine(null);
                      }}
                    />
                  )}
                  {selectedForm === 'ingredients' && (
                    <IngredientsForm
                      machineId={machine.coffeeMachineId}
                      onClose={() => {
                        setSelectedForm(null);
                        setSelectedMachine(null);
                      }}
                    />
                  )}
                </Paper>
              )}
 
              {/* Logs Section */}
              {showLogs[machine.coffeeMachineId] && logs[machine.coffeeMachineId] && (
                <Box sx={{ mt: 2 }}>
                  <Divider sx={{ mb: 2 }} />
                  <LogsDisplay logs={logs[machine.coffeeMachineId]} />
                </Box>
              )}
            </CardContent>
          </Card>
        ))}
      </Box>
      </Container>
    </Box>
  );
}
 
export default MachineActionTechnician;