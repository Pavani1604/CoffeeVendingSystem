import axiosInstance from './axiosConfig';

const API_PATH = '/api/iot';

export const sendTemperatureData = async (data) => {
    try {
        // Get authentication token
        const userData = localStorage.getItem('authUser');
        const token = userData ? JSON.parse(userData).token : null;
        
        if (!token) {
            throw new Error('Not authenticated. Please login again.');
        }

        // Format the data according to the API requirements
        const payload = {
            temperature: parseFloat(data.temperature),
            coffeeMachineId: parseInt(data.coffeeMachineId),
            recordedAt: data.recordedAt
        };
        console.log('Sending temperature data with payload:', payload);
        // For temperature API, send only required fields
        const response = await axiosInstance.post(`${API_PATH}/temperature`, payload);
        console.log('Temperature API response:', response.data);
        return response.data;
    } catch (error) {
        console.error('Temperature data error:', error.response || error);
        throw error;
    }
};

export const sendIngredientsData = async (data) => {
    try {
        // Get authentication token
        const userData = localStorage.getItem('authUser');
        const token = userData ? JSON.parse(userData).token : null;
        
        if (!token) {
            throw new Error('Not authenticated. Please login again.');
        }

        // Format data according to API requirements
        const payload = {
            coffeeMachineId: parseInt(data.coffeeMachineId),
            waterLevel: `${data.waterLevel}%`,
            coffeePowder: `${data.coffeePowder}%`,
            milkLevel: `${data.milkLevel}%`,
            teaPowder: `${data.teaPowder}%`,
            sugarLevel: `${data.sugarLevel}%`,
            recordedAt: data.recordedAt
        };
        console.log('Sending ingredients data with payload:', payload);
        // For ingredients API, send all levels with % and required fields
        const response = await axiosInstance.post(`${API_PATH}/ingredients`, payload);
        console.log('Ingredients API response:', response.data);
        return response.data;
    } catch (error) {
        console.error('Ingredients data error:', error.response || error);
        throw error;
    }
};

export const updateMachine = async (coffeeMachineId, temperature, ingredients) => {
    try {
        const payload = {
            temperature,
            ...ingredients,
        };
        const response = await axiosInstance.put(`/api/coffee-machines/${coffeeMachineId}`, payload);
        return response.data;
    } catch (error) {
        console.error('Error updating machine:', error);
        throw error;
    }
};

export const updateAllItems = async (machineId, updateData) => {
    try {
        const response = await axiosInstance.put(
            `/api/update-all/${machineId}`,
            updateData
        );
        return response.data;
    } catch (error) {
        console.error('Update all items error:', error);
        throw error;
    }
};
