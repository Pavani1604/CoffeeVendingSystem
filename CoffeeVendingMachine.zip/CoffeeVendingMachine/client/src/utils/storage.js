export const saveUserData = (userData) => {
    localStorage.setItem('authUser', JSON.stringify({
        token: userData.token,
        name: userData.name,
        email: userData.email,
        role: userData.role
    }));
};

export const getUserData = () => {
    const data = localStorage.getItem('authUser');
    return data ? JSON.parse(data) : null;
};

export const isAuthenticated = () => {
    const userData = getUserData();
    return !!userData?.token;
};

export const hasRole = (requiredRole) => {
    const userData = getUserData();
    return userData?.role?.toLowerCase() === requiredRole?.toLowerCase();
};

export const getToken = () => {
    const userData = getUserData();
    return userData?.token;
};

export const clearUserData = () => {
    localStorage.removeItem('authUser');
};
