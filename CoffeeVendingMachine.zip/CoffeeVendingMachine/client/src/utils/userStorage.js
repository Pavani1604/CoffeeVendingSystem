export const saveRegisteredUser = (userData) => {
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    users.push(userData);
    localStorage.setItem('registeredUsers', JSON.stringify(users));
};

export const verifyUser = (email, password) => {
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    return users.find(user => user.email === email && user.password === password);
};
