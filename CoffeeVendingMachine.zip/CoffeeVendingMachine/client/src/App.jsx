import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './Components/Login';
import Register from './Components/Register';
import Technician from './Components/Technician'; // Import Technician component
import { isAuthenticated, hasRole } from './utils/storage';
import './App.css';
import React, { useState } from "react";
import LocationSearch from "./Components/LocationSearch";
import BranchList from "./Components/BranchList";
import MachineActionTechnician from "./Components/MachineActionTechnician";
import MachineAction from "./Components/MachineAction";
import Home from './Components/Home';
 
const ProtectedRoute = ({ children, requiredRole }) => {
  if (!isAuthenticated()) {
    return <Navigate to="/login" />;
  }
  if (requiredRole && !hasRole(requiredRole)) {
    return <Navigate to="/unauthorized" />;
  }
  return children;
};
 
  const AdminDashboard = () => {
    const [selectedLocation, setSelectedLocation] = useState(null);
    const [selectedBranch, setSelectedBranch] = useState(null);
 
    return (
      <div style={{ fontFamily: "Arial, sans-serif", padding: "20px", paddingTop: "80px" }}>
        <h1 style={{ textAlign: "center", color: "#333" }}>Admin Dashboard</h1>
        {!selectedLocation ? (
          <LocationSearch onSelectLocation={setSelectedLocation} />
        ) : !selectedBranch ? (
          <BranchList
            locationId={selectedLocation.id}
            onSelectBranch={setSelectedBranch}
            onBack={() => setSelectedLocation(null)}
          />
        ) : (
          <MachineAction
            branchId={selectedBranch.id}
            onBack={() => setSelectedBranch(null)}
          />
        )}
      </div>
    );
  };
 
const TechnicianDashboard = () => {
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [selectedBranch, setSelectedBranch] = useState(null);
 
  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "20px", paddingTop: "80px" }}>
        <h1 style={{ textAlign: "center", color: "#333" }}>Technician Manager</h1>
      {!selectedLocation ? (
        <LocationSearch onSelectLocation={setSelectedLocation} />
      ) : !selectedBranch ? (
        <BranchList
          locationId={selectedLocation.id}
          onSelectBranch={setSelectedBranch}
          onBack={() => setSelectedLocation(null)}
        />
      ) : (
        <MachineActionTechnician
          branchId={selectedBranch.id}
          onBack={() => setSelectedBranch(null)}
        />
      )}
    </div>
  );
};
 
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/admin" element={
          <ProtectedRoute requiredRole="ADMIN">
            <AdminDashboard />
          </ProtectedRoute>
        } />
        <Route path="/technician" element={
          <ProtectedRoute requiredRole="TECHNICIAN">
            <TechnicianDashboard />
          </ProtectedRoute>
        } />
        <Route path="/unauthorized" element={<div>Unauthorized Access</div>} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </BrowserRouter>
  );
}
 
export default App;
 
 