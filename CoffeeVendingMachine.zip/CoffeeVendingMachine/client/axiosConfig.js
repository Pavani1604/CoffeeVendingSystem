import axios from 'axios';

// ...existing code...

axios.interceptors.request.use(
  (config) => {
    console.log('Request payload:', config.data);
    console.log('Request headers:', config.headers);
    return config;
  },
  (error) => {
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  (response) => {
    console.log('Response data:', response.data);
    return response;
  },
  (error) => {
    if (error.response) {
      const { status, data } = error.response;
      const message = data?.message || 'An unexpected error occurred on the server.';
      console.error('Response error:', { status, message, data });
      alert(`Error ${status}: ${message}`); // Provide user feedback
    } else {
      console.error('Network or other error:', error.message);
      alert('A network error occurred. Please check your connection.');
    }
    return Promise.reject(error);
  }
);

// ...existing code...