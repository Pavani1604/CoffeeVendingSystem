package com.example.coffee.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.coffee.entity.CoffeeIngredients;
import com.example.coffee.entity.CoffeeMachine;
import com.example.coffee.dto.CoffeeIngredientsDTO;
import com.example.coffee.repository.CoffeeIngredientsRepository;
import com.example.coffee.repository.CoffeeMachineRepository;

@Service
public class CoffeeIngredientsService {
    @Autowired
    private CoffeeIngredientsRepository coffeeIngredientsRepository;
    @Autowired
    private CoffeeMachineRepository coffeeMachineRepository;

    public CoffeeIngredientsDTO saveCoffeeIngredients(CoffeeIngredientsDTO dto) {
        try {
            if (dto.getCoffeeMachineId() == null) {
                throw new IllegalArgumentException("Coffee machine ID cannot be null");
            }

            CoffeeIngredients entity = convertToEntity(dto);
            
            // Set current time if recordedAt is not provided
            if (entity.getRecordedAt() == null) {
                entity.setRecordedAt(LocalDateTime.now());
            }

            entity = coffeeIngredientsRepository.save(entity);
            return convertToDTO(entity);
        } catch (Exception e) {
            throw new RuntimeException("Failed to save ingredients data: " + e.getMessage());
        }
    }

    public List<CoffeeIngredientsDTO> getAllCoffeeIngredients() {
        return coffeeIngredientsRepository.findAll()
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    public List<CoffeeIngredientsDTO> getIngredientsByMachineId(Long coffeeMachineId) {
        return coffeeIngredientsRepository.findByCoffeeMachineId(coffeeMachineId)
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }

    public CoffeeIngredients getCoffeeIngredientsById(Long id) {
        return coffeeIngredientsRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Coffee Ingredients not found"));
    }

    public void updateCoffeeIngredients(CoffeeIngredients coffeeIngredients) {
        coffeeIngredientsRepository.save(coffeeIngredients);
    }

    private CoffeeIngredients convertToEntity(CoffeeIngredientsDTO dto) {
        CoffeeIngredients entity = new CoffeeIngredients();
        BeanUtils.copyProperties(dto, entity);
        
        // Set current time if recordedAt is not provided
        if (entity.getRecordedAt() == null) {
            entity.setRecordedAt(LocalDateTime.now());
        }
        
        if (dto.getCoffeeMachineId() != null) {
            CoffeeMachine coffeeMachine = coffeeMachineRepository.findById(dto.getCoffeeMachineId())
                .orElseThrow(() -> new RuntimeException("CoffeeMachine not found with id: " + dto.getCoffeeMachineId()));
            entity.setCoffeeMachine(coffeeMachine);
        }
        
        return entity;
    }
    
    private CoffeeIngredientsDTO convertToDTO(CoffeeIngredients entity) {
        CoffeeIngredientsDTO dto = new CoffeeIngredientsDTO();
        BeanUtils.copyProperties(entity, dto);
        return dto;
    }
    public CoffeeIngredientsDTO updateCoffeeIngredients(Long id, CoffeeIngredientsDTO dto) {
        CoffeeIngredients existingEntity = coffeeIngredientsRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("CoffeeIngredients not found with id: " + id));
 
        // Update fields from dto to existingEntity
        if (dto.getSugarLevel() != null) {
            existingEntity.setSugarLevel(dto.getSugarLevel());
        }
        if (dto.getMilkLevel() != null) {
            existingEntity.setMilkLevel(dto.getMilkLevel());
        }
        if (dto.getCoffeePowder() != null) {
            existingEntity.setCoffeePowder(dto.getCoffeePowder());
        }
        if (dto.getTeaPowder() != null) {
            existingEntity.setTeaPowder(dto.getTeaPowder());
        }
        if (dto.getWaterLevel() != null) {
            existingEntity.setWaterLevel(dto.getWaterLevel());
        }
        if (dto.getRecordedAt() != null) {
            existingEntity.setRecordedAt(dto.getRecordedAt());
        }
        if (dto.getType() != null) {
            existingEntity.setType(dto.getType());
        }
        if (dto.getCoffeeMachineId() != null) {
            CoffeeMachine coffeeMachine = coffeeMachineRepository.findById(dto.getCoffeeMachineId())
                .orElseThrow(() -> new RuntimeException("CoffeeMachine not found with id: " + dto.getCoffeeMachineId()));
            existingEntity.setCoffeeMachine(coffeeMachine);
        }
 
        CoffeeIngredients updatedEntity = coffeeIngredientsRepository.save(existingEntity);
        return convertToDTO(updatedEntity);
    }
 
}
