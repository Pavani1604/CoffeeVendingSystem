package com.example.coffee.entity;

import jakarta.persistence.*;
import com.google.gson.Gson;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "machine_temperature")
public class MachineTemperature {
   
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "temp_id")
    private Long tempId;

    @Column(name = "temperature", nullable = false)
    private double temperature;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "coffee_machine_id", nullable = false)
    private CoffeeMachine coffeeMachine;

    @Transient
    private Long coffeeMachineId;

    @Column(name = "type")
    private String type;

    @Column(name = "recorded_at", nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime recordedAt;

    @PrePersist
    protected void onCreate() {
        if (recordedAt == null) {
            recordedAt = LocalDateTime.now();
        }
    }

    public String serialize() {
        return new Gson().toJson(this);
    }
    public Long getTempId() {
        return tempId;
    }
    public void setTempId(Long tempId) {
        this.tempId = tempId;
    }
    public double getTemperature() {
        return temperature;
    }
    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
    public CoffeeMachine getCoffeeMachine() {
        return coffeeMachine;
    }
    public void setCoffeeMachine(CoffeeMachine coffeeMachine) {
        this.coffeeMachine = coffeeMachine;
    }
    public Long getCoffeeMachineId() {
        return coffeeMachine != null ? coffeeMachine.getCoffeeMachineId() : null;
    }
    public void setCoffeeMachineId(Long coffeeMachineId) {
        this.coffeeMachineId = coffeeMachineId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public LocalDateTime getRecordedAt() {
        return recordedAt;
    }
    public void setRecordedAt(LocalDateTime recordedAt) {
        this.recordedAt = recordedAt;
    }
    public MachineTemperature() {
    }
    public MachineTemperature(Long tempId, double temperature, CoffeeMachine coffeeMachine, String type) {
        this.tempId = tempId;
        this.temperature = temperature;
        this.coffeeMachine = coffeeMachine;
        this.type = type;
    }
}