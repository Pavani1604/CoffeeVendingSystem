package com.example.coffee.dto;

public class CoffeeIngredientsLogsDTO {
    private Long ingredientId;
    private String waterLevel;
    private String coffeePowder;
    private String milkLevel;
    private String teaPowder;
    private String sugarLevel;
    private String recordedAt;

    // Constructor
    public CoffeeIngredientsLogsDTO() {}

    public CoffeeIngredientsLogsDTO(Long ingredientId, String waterLevel, String coffeePowder,
                                   String milkLevel, String teaPowder, String sugarLevel,
                                   String recordedAt) {
        this.ingredientId = ingredientId;
        this.waterLevel = waterLevel;
        this.coffeePowder = coffeePowder;
        this.milkLevel = milkLevel;
        this.teaPowder = teaPowder;
        this.sugarLevel = sugarLevel;
        this.recordedAt = recordedAt;
    }

    // Getters and Setters
    public Long getIngredientId() { return ingredientId; }
    public void setIngredientId(Long ingredientId) { this.ingredientId = ingredientId; }
    
    public String getWaterLevel() { return waterLevel; }
    public void setWaterLevel(String waterLevel) { this.waterLevel = waterLevel; }
    
    public String getCoffeePowder() { return coffeePowder; }
    public void setCoffeePowder(String coffeePowder) { this.coffeePowder = coffeePowder; }
    
    public String getMilkLevel() { return milkLevel; }
    public void setMilkLevel(String milkLevel) { this.milkLevel = milkLevel; }
    
    public String getTeaPowder() { return teaPowder; }
    public void setTeaPowder(String teaPowder) { this.teaPowder = teaPowder; }
    
    public String getSugarLevel() { return sugarLevel; }
    public void setSugarLevel(String sugarLevel) { this.sugarLevel = sugarLevel; }
    
    public String getRecordedAt() { return recordedAt; }
    public void setRecordedAt(String recordedAt) { this.recordedAt = recordedAt; }
}
