package com.example.coffee.service;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.azure.messaging.servicebus.*;
import com.example.coffee.entity.*;
import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;

@Service
public class ServiceBusListener {
    @Value("${azure.servicebus.connection-string}")
    private String connectionString;
    
    @Value("${azure.servicebus.topic-name}")
    private String topicName;
    
    @Value("${azure.servicebus.subscription-name}")
    private String subscriptionName;

    @Value("${spring.datasource.url}")
    private String jdbcUrl;

    @Value("${spring.datasource.username}")
    private String jdbcUsername;

    @Value("${spring.datasource.password}")
    private String jdbcPassword;

    @PersistenceContext
    private EntityManager entityManager;

    private ServiceBusProcessorClient processorClient;

    @PostConstruct
    public void startListening() {
        processorClient = new ServiceBusClientBuilder()
                .connectionString(connectionString)
                .processor()
                .topicName(topicName)
                .subscriptionName(subscriptionName)
                .processMessage(this::processMessage)
                .processError(this::processError)
                .buildProcessorClient();

        System.out.println("Starting Coffee Machine Service Bus listener...");
        processorClient.start();
    }

    public void processMessage(ServiceBusReceivedMessageContext context) {
        ServiceBusReceivedMessage message = context.getMessage();
        System.out.println("Received message: " + message.getBody());

        try {
            JSONObject jsonObj = new JSONObject(message.getBody().toString());
            
            // Safe type conversion for coffeeMachineId
            Long coffeeMachineId = null;
            if (jsonObj.has("coffeeMachineId") && !jsonObj.isNull("coffeeMachineId")) {
                Object idObj = jsonObj.get("coffeeMachineId");
                if (idObj instanceof Number) {
                    coffeeMachineId = ((Number) idObj).longValue();
                } else if (idObj instanceof String) {
                    coffeeMachineId = Long.parseLong((String) idObj);
                }
            }

            if (coffeeMachineId == null) {
                throw new IllegalArgumentException("Missing or invalid coffeeMachineId");
            }

            int type = jsonObj.has("type") ? 
                Integer.parseInt(jsonObj.optString("type", "1")) : 
                Integer.parseInt(message.getApplicationProperties().getOrDefault("type", "1").toString());

            String recordedAt = LocalDateTime.now().toString();

            switch(type) {
                case 1: // Temperature data
                    double temperature = jsonObj.getDouble("temperature");
                    try (Connection connection = DriverManager.getConnection(jdbcUrl, jdbcUsername, jdbcPassword)) {
                        connection.setAutoCommit(false);
                        String insertSql = "INSERT INTO machine_temperature (coffee_machine_id, temperature, type, recorded_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP)";
                        try (PreparedStatement stmt = connection.prepareStatement(insertSql)) {
                            stmt.setLong(1, coffeeMachineId);
                            stmt.setDouble(2, temperature);
                            stmt.setString(3, String.valueOf(type));
                            stmt.executeUpdate();
                            connection.commit();
                            System.out.println("Temperature data inserted successfully for machine: " + coffeeMachineId);
                        }
                    } catch (Exception e) {
                        System.err.println("Error processing temperature message: " + e.getMessage());
                        e.printStackTrace();
                    }
                    break;

                case 2: // Ingredients data
                    try (Connection connection = DriverManager.getConnection(jdbcUrl, jdbcUsername, jdbcPassword)) {
                        connection.setAutoCommit(false);
                        String insertSql = "INSERT INTO coffee_ingredients (coffee_machine_id, type, water_level, coffee_powder, milk_level, tea_powder, sugar_level, recorded_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
                        try (PreparedStatement stmt = connection.prepareStatement(insertSql)) {
                            stmt.setLong(1, coffeeMachineId);
                            stmt.setString(2, String.valueOf(type));
                            stmt.setString(3, jsonObj.getString("waterLevel"));
                            stmt.setString(4, jsonObj.getString("coffeePowder"));
                            stmt.setString(5, jsonObj.getString("milkLevel"));
                            stmt.setString(6, jsonObj.getString("teaPowder"));
                            stmt.setString(7, jsonObj.getString("sugarLevel"));
                            
                            int rowsAffected = stmt.executeUpdate();
                            connection.commit();
                            System.out.println("Ingredients data inserted successfully. Rows affected: " + rowsAffected);
                        } catch (Exception e) {
                            connection.rollback();
                            throw e;
                        }
                    } catch (Exception e) {
                        System.err.println("Error inserting ingredients data: " + e.getMessage());
                        e.printStackTrace();
                    }
                    break;
            }
        } catch (Exception e) {
            System.err.println("Error processing message: " + e.getMessage());
            e.printStackTrace(); // Add stack trace for debugging
        }
    }

    private void processError(ServiceBusErrorContext context) {
        System.err.println("Error occurred: " + context.getException().getMessage());
    }
}
