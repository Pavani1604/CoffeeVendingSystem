package com.example.coffee.service;

import com.example.coffee.dto.*;
import com.example.coffee.entity.*;
import com.example.coffee.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class CoffeeMachineLogsService {
    private static final Logger logger = LoggerFactory.getLogger(CoffeeMachineLogsService.class);

    @Autowired
    private CoffeeMachineRepository coffeeMachineRepository;

    public CoffeeMachineLogsDTO getMachineLogs(Long machineId) {
        try {
            if (machineId == null) {
                throw new IllegalArgumentException("Machine ID cannot be null");
            }

            CoffeeMachine machine = coffeeMachineRepository.findById(machineId)
                .orElseThrow(() -> new RuntimeException("Coffee Machine not found with ID: " + machineId));

            // Get latest temperature with null checks
            MachineTemperatureDTO latestTemp = null;
            List<MachineTemperature> temperatures = machine.getMachineTemperatures();
            if (temperatures != null && !temperatures.isEmpty()) {
                MachineTemperature latest = temperatures.get(temperatures.size() - 1);
                if (latest != null) {
                    latestTemp = new MachineTemperatureDTO(
                        latest.getTempId(),
                        latest.getTemperature(),
                        latest.getType()
                    );
                }
            }

            // Get ingredients logs with null checks
            List<CoffeeIngredientsLogsDTO> ingredientsLogs = new ArrayList<>();
            if (machine.getCoffeeIngredients() != null) {
                ingredientsLogs = machine.getCoffeeIngredients().stream()
                    .filter(ing -> ing != null)
                    .map(ing -> {
                        try {
                            return new CoffeeIngredientsLogsDTO(
                                ing.getCoffeeIngredientId(),
                                Optional.ofNullable(ing.getWaterLevel()).orElse("N/A"),
                                Optional.ofNullable(ing.getCoffeePowder()).orElse("N/A"),
                                Optional.ofNullable(ing.getMilkLevel()).orElse("N/A"),
                                Optional.ofNullable(ing.getTeaPowder()).orElse("N/A"),
                                Optional.ofNullable(ing.getSugarLevel()).orElse("N/A"),
                                Optional.ofNullable(ing.getRecordedAt()).map(Object::toString).orElse("N/A")
                            );
                        } catch (Exception e) {
                            logger.error("Error mapping ingredients for machine {}: {}", machineId, e.getMessage());
                            return null;
                        }
                    })
                    .filter(dto -> dto != null)
                    .collect(Collectors.toList());
            }

            return new CoffeeMachineLogsDTO(
                machine.getCoffeeMachineId(),
                Optional.ofNullable(machine.getStatus()).map(Object::toString).orElse("UNKNOWN"),
                Optional.ofNullable(machine.getBranch()).map(Branch::getId).orElse(null),
                Optional.ofNullable(machine.getMachineCode()).orElse("N/A"),
                latestTemp,
                ingredientsLogs
            );
        } catch (Exception e) {
            logger.error("Error getting machine logs for machine {}: {}", machineId, e.getMessage());
            throw new RuntimeException("Error retrieving machine logs: " + e.getMessage());
        }
    }
}
