package com.example.coffee.repository;

import com.example.coffee.entity.MachineTemperature;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MachineTemperatureRepository extends JpaRepository<MachineTemperature, Long> {
    @Query("SELECT mt FROM MachineTemperature mt ORDER BY mt.recordedAt DESC")
    List<MachineTemperature> findRecentTemperatureLogs();
    
    @Query("SELECT mt FROM MachineTemperature mt WHERE mt.coffeeMachine.coffeeMachineId = :machineId")
    List<MachineTemperature> findByCoffeeMachineId(Long machineId);
}
