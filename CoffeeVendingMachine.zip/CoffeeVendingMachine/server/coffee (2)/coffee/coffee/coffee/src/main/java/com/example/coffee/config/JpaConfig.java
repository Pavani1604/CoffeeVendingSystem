package com.example.coffee.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(basePackages = "com.example.coffee.repository")
@EnableTransactionManagement
public class JpaConfig {
    // Configuration is handled through application.properties
}
