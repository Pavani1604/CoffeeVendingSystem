package com.example.coffee.repository;

import com.example.coffee.entity.CoffeeIngredients;
import com.example.coffee.entity.MachineTemperature;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
@Repository

public interface CoffeeIngredientsRepository extends JpaRepository<CoffeeIngredients, Long> {
    @Query("SELECT ci FROM CoffeeIngredients ci WHERE ci.coffeeMachine.coffeeMachineId = :coffeeMachineId")
    List<CoffeeIngredients> findByCoffeeMachineId(@Param("coffeeMachineId") Long coffeeMachineId);

    @Query(value = "SELECT TOP 10 * FROM coffee_ingredients ORDER BY recorded_at DESC", nativeQuery = true)
    List<CoffeeIngredients> findRecentIngredientsLogs();
}