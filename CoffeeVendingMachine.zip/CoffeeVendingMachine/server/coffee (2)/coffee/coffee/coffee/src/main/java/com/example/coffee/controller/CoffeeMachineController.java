package com.example.coffee.controller;

import com.example.coffee.entity.CoffeeIngredients;
import com.example.coffee.entity.CoffeeMachine;
import com.example.coffee.service.CoffeeMachineService;
import com.example.coffee.dto.CoffeeMachineDTO;
import com.example.coffee.service.CoffeeIngredientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/coffee-machines")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class CoffeeMachineController {

    @Autowired
    private CoffeeMachineService coffeeMachineService;

    @Autowired
    private CoffeeIngredientsService coffeeIngredientsService;

    @PostMapping("/create")
    public ResponseEntity<CoffeeMachine> createCoffeeMachine(@RequestBody CoffeeMachineDTO dto) {
        return ResponseEntity.ok(coffeeMachineService.createCoffeeMachine(dto));
    }

    @PutMapping("/{id}/toggle-status")
    public ResponseEntity<CoffeeMachine> toggleStatus(@PathVariable("id") Long coffeeMachineId) {
        return ResponseEntity.ok(coffeeMachineService.toggleStatus(coffeeMachineId));
    }

    @GetMapping("/branch/{branchId}")
    public ResponseEntity<List<CoffeeMachine>> getMachinesByBranch(@PathVariable Long branchId) {
        return ResponseEntity.ok(coffeeMachineService.getMachinesByBranch(branchId));
    }

    @GetMapping
    public ResponseEntity<java.util.List<CoffeeMachine>> getAllMachines() {
        return ResponseEntity.ok(coffeeMachineService.getAllMachines());
    }

    // @GetMapping("/{id}")
    // public ResponseEntity<CoffeeMachine> getCoffeeMachineById(@PathVariable Long id) {
    //     return ResponseEntity.ok(coffeeMachineService.getCoffeeMachineById(id));
    // }

    // @PutMapping("/{id}")
    // public ResponseEntity<CoffeeMachine> updateCoffeeMachine(
    //         @PathVariable("id") Long coffeeMachineId,
    //         @RequestBody CoffeeMachine updateCoffeeMachine) {
    //     CoffeeMachine machine = coffeeMachineService.getCoffeeMachineById(coffeeMachineId);
    //     if (machine == null) {
    //         return ResponseEntity.notFound().build();
    //     }

    //     CoffeeIngredients coffeeIngredients = coffeeIngredientsService.getCoffeeIngredientsById(coffeeMachineId);
    //     if (coffeeIngredients == null) {
    //         return ResponseEntity.status(404).body(null);
    //     }

    //     machine.setTemperature(updateCoffeeMachine.getTemperature());
    //     coffeeIngredients.setWaterLevel(updateCoffeeMachine.getCoffeeIngredients().getWaterLevel());
    //     coffeeIngredients.setCoffeePowder(updateCoffeeMachine.getCoffeeIngredients().getCoffeePowder());
    //     coffeeIngredients.setMilkLevel(updateCoffeeMachine.getCoffeeIngredients().getMilkLevel());
    //     coffeeIngredients.setSugarLevel(updateCoffeeMachine.getCoffeeIngredients().getSugarLevel());
    //     coffeeIngredientsService.updateCoffeeIngredients(coffeeIngredients);

    //     machine.setCoffeeIngredients(coffeeIngredients);
    //     machine.setStatus(updateCoffeeMachine.getStatus());
    //     machine.setBranch(updateCoffeeMachine.getBranch());
    //     machine.setMachineCode(updateCoffeeMachine.getMachineCode());

    //     CoffeeMachine savedMachine = coffeeMachineService.saveMachine(machine);
    //     return ResponseEntity.ok(savedMachine);
    // }

    // // @DeleteMapping("/{id}")
    // // public ResponseEntity<Void> deleteCoffeeMachine(@PathVariable Long id) {
    // //     coffeeMachineService.deleteCoffeeMachine(id);
    // //     return ResponseEntity.noContent().build();
    // // }
}
