package com.example.coffee.entity;

import jakarta.persistence.*;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.example.coffee.entity.CoffeeIngredients; // Ensure this import matches the actual package of CoffeeIngredient
import java.util.List;

@Entity
@Table(name = "coffee_machines")
public class CoffeeMachine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "coffee_machine_id") // Update column name to match database
    private Long coffeeMachineId;

    @Column(nullable = false, unique = true, name = "machine_code")  // Update column name
    private String machineCode;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CoffeeMachineStatus status = CoffeeMachineStatus.INACTIVE;

    @JsonBackReference
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @OneToMany(mappedBy = "coffeeMachine", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<CoffeeIngredients> coffeeIngredients;

    @OneToMany(mappedBy = "coffeeMachine", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<MachineTemperature> machineTemperatures;

    public CoffeeMachine() {
    }
    public CoffeeMachine(String machineCode, CoffeeMachineStatus status, Branch branch) {
        this.machineCode = machineCode;
        this.status = status;
        this.branch = branch;
    }
    public Long getCoffeeMachineId() {
        return coffeeMachineId;
    }
    public void setCoffeeMachineId(Long coffeeMachineId) {
        this.coffeeMachineId = coffeeMachineId;
    }
    public String getMachineCode() {
        return machineCode;
    }
    public void setMachineCode(String machineCode) {
        this.machineCode = machineCode;
    }
    public CoffeeMachineStatus getStatus() {
        return status;
    }
    public void setStatus(CoffeeMachineStatus status) {
        this.status = status;
    }
    public Branch getBranch() {
        return branch;
    }
    public void setBranch(Branch branch) {
        this.branch = branch;
    }
    
    public List<CoffeeIngredients> getCoffeeIngredients() {
        return coffeeIngredients;
    }

    public void setCoffeeIngredients(List<CoffeeIngredients> coffeeIngredients) {
        this.coffeeIngredients = coffeeIngredients;
    }

    public List<MachineTemperature> getMachineTemperatures() {
        return machineTemperatures;
    }

    public void setMachineTemperatures(List<MachineTemperature> machineTemperatures) {
        this.machineTemperatures = machineTemperatures;
    }
}
