package com.example.coffee.dto;

import java.util.List;

public class CoffeeMachineLogsDTO {
    private Long coffeeMachineId;
    private String status;
    private Long branchId;
    private String machineCode;
    private MachineTemperatureDTO latestTemperature;
    private List<CoffeeIngredientsLogsDTO> ingredientsLogs;

    // Constructor
    public CoffeeMachineLogsDTO() {}

    public CoffeeMachineLogsDTO(Long coffeeMachineId, String status, Long branchId, 
                               String machineCode, MachineTemperatureDTO latestTemperature, 
                               List<CoffeeIngredientsLogsDTO> ingredientsLogs) {
        this.coffeeMachineId = coffeeMachineId;
        this.status = status;
        this.branchId = branchId;
        this.machineCode = machineCode;
        this.latestTemperature = latestTemperature;
        this.ingredientsLogs = ingredientsLogs;
    }

    // Getters and Setters
    public Long getCoffeeMachineId() { return coffeeMachineId; }
    public void setCoffeeMachineId(Long coffeeMachineId) { this.coffeeMachineId = coffeeMachineId; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public Long getBranchId() { return branchId; }
    public void setBranchId(Long branchId) { this.branchId = branchId; }
    
    public String getMachineCode() { return machineCode; }
    public void setMachineCode(String machineCode) { this.machineCode = machineCode; }
    
    public MachineTemperatureDTO getLatestTemperature() { return latestTemperature; }
    public void setLatestTemperature(MachineTemperatureDTO latestTemperature) { this.latestTemperature = latestTemperature; }
    
    public List<CoffeeIngredientsLogsDTO> getIngredientsLogs() { return ingredientsLogs; }
    public void setIngredientsLogs(List<CoffeeIngredientsLogsDTO> ingredientsLogs) { this.ingredientsLogs = ingredientsLogs; }
}
