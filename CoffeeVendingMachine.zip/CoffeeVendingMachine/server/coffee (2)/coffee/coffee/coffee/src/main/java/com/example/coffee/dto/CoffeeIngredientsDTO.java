package com.example.coffee.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class CoffeeIngredientsDTO {

    private Long coffeeIngredientId;
    private String sugarLevel;
    private String milkLevel;
    private String coffeePowder;
    private String teaPowder;
    private String waterLevel;
   // private String recordedAt;
    private Long coffeeMachineId;
    private String type;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime recordedAt;

    public CoffeeIngredientsDTO() {
    }
    public CoffeeIngredientsDTO(Long coffeeIngredientId, String sugarLevel, String milkLevel, String coffeePowder, String teaPowder, String waterLevel,LocalDateTime recordedAt) {
        this.coffeeIngredientId = coffeeIngredientId;
        this.sugarLevel = sugarLevel;
        this.milkLevel = milkLevel;
        this.coffeePowder = coffeePowder;
        this.teaPowder = teaPowder;
        this.waterLevel = waterLevel;
        this.recordedAt = recordedAt;
    }

    public Long getCoffeeIngredientId() {
        return coffeeIngredientId;
    }
    public void setCoffeeIngredientId(Long coffeeIngredientId) {
        this.coffeeIngredientId = coffeeIngredientId;
    }
    public String getSugarLevel() {
        return sugarLevel;
    }
    public void setSugarLevel(String sugarLevel) {
        this.sugarLevel = sugarLevel;
    }
    public String getMilkLevel() {
        return milkLevel;
    }
    public void setMilkLevel(String milkLevel) {
        this.milkLevel = milkLevel;
    }
    public String getCoffeePowder() {
        return coffeePowder;
    }
    public void setCoffeePowder(String coffeePowder) {
        this.coffeePowder = coffeePowder;
    }
    public String getTeaPowder() {
        return teaPowder;
    }
    public void setTeaPowder(String teaPowder) {
        this.teaPowder = teaPowder;
    }
    public String getWaterLevel() {
        return waterLevel;
    }
    public void setWaterLevel(String waterLevel) {
        this.waterLevel = waterLevel;
    }
    public LocalDateTime getRecordedAt() {
        return recordedAt;
    }
    public void setRecordedAt(LocalDateTime recordedAt) {
        this.recordedAt = recordedAt;
    }
    public Long getCoffeeMachineId() {
        return coffeeMachineId;
    }
    public void setCoffeeMachineId(Long coffeeMachineId) {
        this.coffeeMachineId = coffeeMachineId;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

}
