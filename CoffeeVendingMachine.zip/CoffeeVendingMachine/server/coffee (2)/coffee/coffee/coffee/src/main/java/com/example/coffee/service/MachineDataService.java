package com.example.coffee.service;

import com.example.coffee.dto.RecentLogsDTO;
import com.example.coffee.repository.MachineTemperatureRepository;
import com.example.coffee.repository.CoffeeIngredientsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MachineDataService {
    @Autowired
    private MachineTemperatureRepository temperatureRepository;

    @Autowired
    private CoffeeIngredientsRepository ingredientsRepository;

    public List<RecentLogsDTO> getRecentTemperatureLogs() {
        return temperatureRepository.findRecentTemperatureLogs()
            .stream()
            .map(temp -> new RecentLogsDTO(
                temp.getTempId(),
                temp.getRecordedAt() != null ? temp.getRecordedAt() : LocalDateTime.now(),
                "TEMPERATURE",
                temp
            ))
            .collect(Collectors.toList());
    }

    public List<RecentLogsDTO> getRecentIngredientsLogs() {
        return ingredientsRepository.findRecentIngredientsLogs()
            .stream()
            .map(ing -> new RecentLogsDTO(
                ing.getCoffeeIngredientId(),
                LocalDateTime.parse(ing.getRecordedAt().toString()),
                "INGREDIENTS",
                ing
            ))
            .collect(Collectors.toList());
    }
}
