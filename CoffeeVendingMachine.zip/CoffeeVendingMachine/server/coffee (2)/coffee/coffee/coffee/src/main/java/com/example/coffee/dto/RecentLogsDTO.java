package com.example.coffee.dto;

import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonFormat;

import com.example.coffee.entity.CoffeeIngredients;

public class RecentLogsDTO {
    private Long id;
    
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime timestamp;
    private String logType;
    private Object data;

    public RecentLogsDTO() {}

    public RecentLogsDTO(Long id, LocalDateTime timestamp, String logType, Object data) {
        this.id = id;
        this.timestamp = timestamp;
        this.logType = logType;
        this.data = data;
    }
    public RecentLogsDTO(Long id, String recordedAt, String type, CoffeeIngredients data) {
        this.id = id;
        this.timestamp = LocalDateTime.parse(recordedAt); // Assuming recordedAt is a String in ISO-8601 format
        this.logType = type;
        this.data = data;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
    
    public String getLogType() { return logType; }
    public void setLogType(String logType) { this.logType = logType; }
    
    public Object getData() { return data; }
    public void setData(Object data) { this.data = data; }
}
