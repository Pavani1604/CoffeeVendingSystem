package com.example.coffee.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.coffee.entity.MachineTemperature;
import com.example.coffee.dto.CoffeeIngredientsDTO;
import com.example.coffee.dto.MachineTemperatureDTO;
import com.example.coffee.service.MachineTemperatureService;
import com.example.coffee.service.CoffeeIngredientsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.sdk.iot.device.*;
import com.example.coffee.service.MachineDataService;
import com.microsoft.azure.sdk.iot.device.exceptions.IotHubClientException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.coffee.service.CoffeeMachineLogsService;
import com.example.coffee.dto.RecentLogsDTO;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/iot")
@CrossOrigin(origins = "*", allowedHeaders = "*")

public class CoffeeMachineIoTController {

   @Autowired
    private CoffeeIngredientsService coffeeIngredientsService;
 
    @Autowired
    private MachineTemperatureService machineTemperatureService;

    @Autowired
    private MachineDataService machineDataService;

    @Autowired
    private CoffeeMachineLogsService coffeeMachineLogsService;

    private String connStringTemp = "HostName=coffeesystem-hub.azure-devices.net;DeviceId=coffeeitems;SharedAccessKey=UvRDrPzczYOn3ia+DpvHbabteoGd3/ZriukdEgQjuIA=";
    private String connStringIngredients = "HostName=coffeesystem-hub.azure-devices.net;DeviceId=coffeeitems2;SharedAccessKey=GJnu6FIdWoQqL03yK10y03u6NiyZjn3ux4F0wFrgH0M=";
    private static IotHubClientProtocol protocol = IotHubClientProtocol.MQTT;
    private ObjectMapper objectMapper = new ObjectMapper();

    private static class EventCallback implements MessageSentCallback {
        private String status;
        @Override
        public void onMessageSent(Message sentMessage, IotHubClientException exception, Object callbackContext) {
            status = (exception == null ? IotHubStatusCode.OK.toString() : exception.getStatusCode().toString());
            System.out.println("IoT Hub responded to message with status: " + status);
            if (callbackContext != null) {
                synchronized (callbackContext) {
                    callbackContext.notify();
                }
            }
        }
        public String getStatus() {
            return status;
        }
    }

    @PostMapping("/temperature")
    public ResponseEntity<?> sendTemperature(@RequestBody MachineTemperatureDTO dto) {
        try {
            // Set recordedAt if not provided
            if (dto.getRecordedAt() == null) {
                dto.setRecordedAt(LocalDateTime.now());
            }
            
            // Save to database first
            MachineTemperatureDTO savedTemp = machineTemperatureService.saveMachineTemperature(dto);
            if (savedTemp == null) {
                return ResponseEntity.status(500).body("Failed to save temperature data to database");
            }

            DeviceClient client = null;
            try {
                client = new DeviceClient(connStringTemp, protocol);
                client.open(true);

                JSONObject jsonObj = new JSONObject();
                jsonObj.put("temperature", dto.getTemperature());
                jsonObj.put("coffeeMachineId", dto.getCoffeeMachineId());
                jsonObj.put("type", dto.getType());
                jsonObj.put("recordedAt", dto.getRecordedAt() != null ? 
                    dto.getRecordedAt().toString() : 
                    LocalDateTime.now().toString());

                String msgStr = jsonObj.toString();
                Message msg = new Message(msgStr);
               // msg.setProperty("type", "1");
                System.out.println("Sending temperature data: " + msgStr);

                Object lockobj = new Object();
                EventCallback callback = new EventCallback();
                client.sendEventAsync(msg, callback, lockobj);

                synchronized (lockobj) {
                    lockobj.wait(5000);
                }

                String status = callback.getStatus();
                if (status == null) {
                    return ResponseEntity.status(500).body("Timeout waiting for IoT Hub response");
                }
                return ResponseEntity.ok("Temperature data sent successfully: " + status);
            } finally {
                if (client != null) {
                    client.close();
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Add this for debugging
            return ResponseEntity.status(500).body("Error sending temperature data: " + e.getMessage());
        }
    }

    @PostMapping("/ingredients")
    public ResponseEntity<?> sendIngredients(@RequestBody CoffeeIngredientsDTO dto) {
        try {
            // Set recordedAt if not provided
            if (dto.getRecordedAt() == null) {
                dto.setRecordedAt(LocalDateTime.now());
            }
            
            // Save to database first
            CoffeeIngredientsDTO savedDto = coffeeIngredientsService.saveCoffeeIngredients(dto);
            if (savedDto == null) {
                return ResponseEntity.status(500).body("Failed to save ingredients data to database");
            }

            DeviceClient client = null;
            try {
                client = new DeviceClient(connStringIngredients, protocol);
                client.open(true);

                JSONObject jsonObj = new JSONObject();
                // Use the saved data from database
                jsonObj.put("waterLevel", savedDto.getWaterLevel());
                jsonObj.put("coffeePowder", savedDto.getCoffeePowder());
                jsonObj.put("milkLevel", savedDto.getMilkLevel());
                jsonObj.put("teaPowder", savedDto.getTeaPowder());
                jsonObj.put("sugarLevel", savedDto.getSugarLevel());
                jsonObj.put("coffeeMachineId", savedDto.getCoffeeMachineId());
                jsonObj.put("recordedAt", savedDto.getRecordedAt().toString());

                String msgStr = jsonObj.toString();
                Message msg = new Message(msgStr);

                System.out.println("Sending ingredients data: " + msgStr);
                Object lockobj = new Object();
                EventCallback callback = new EventCallback();
                client.sendEventAsync(msg, callback, lockobj);

                synchronized (lockobj) {
                    lockobj.wait(5000);
                }

                String status = callback.getStatus();
                if (status == null) {
                    return ResponseEntity.status(500).body("Timeout waiting for IoT Hub response");
                }
                return ResponseEntity.ok("Ingredients data sent successfully: " + status);
            } finally {
                if (client != null) {
                    client.close();
                }
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error sending ingredients data: " + e.getMessage());
        }
    }

    @GetMapping("/ingredients/{machineId}")
    public ResponseEntity<?> getIngredientsByMachineId(@PathVariable Long machineId) {
        try {
            return ResponseEntity.ok(coffeeIngredientsService.getIngredientsByMachineId(machineId));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching ingredients: " + e.getMessage());
        }
    }
 
    @GetMapping("/temperature/{machineId}")
    public ResponseEntity<?> getTemperatureByMachineId(@PathVariable Long machineId) {
        try {
            return ResponseEntity.ok(machineTemperatureService.getTemperaturesByMachineId(machineId));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching temperature: " + e.getMessage());
        }
    }
    @PatchMapping("/ingredients/{id}")
    public ResponseEntity<?> updateIngredients(@PathVariable Long id, @RequestBody CoffeeIngredientsDTO dto) {
        try {
            CoffeeIngredientsDTO updatedDto = coffeeIngredientsService.updateCoffeeIngredients(id, dto);
            return ResponseEntity.ok(updatedDto);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating ingredients: " + e.getMessage());
        }
    }
 
    @PatchMapping("/temperature/{id}")
    public ResponseEntity<?> updateTemperature(@PathVariable Long id, @RequestBody MachineTemperatureDTO dto) {
        try {
            MachineTemperatureDTO updatedDto = machineTemperatureService.updateMachineTemperature(id, dto);
            return ResponseEntity.ok(updatedDto);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating temperature: " + e.getMessage());
        }
    }

    @GetMapping("/recent-logs/temperature")
    public ResponseEntity<?> getRecentTemperatureLogs() {
        try {
            return ResponseEntity.ok(machineDataService.getRecentTemperatureLogs());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching recent temperature logs: " + e.getMessage());
        }
    }

    @GetMapping("/recent-logs/ingredients")
    @CrossOrigin(origins = "*", allowedHeaders = "*", methods = {RequestMethod.GET})
    public ResponseEntity<?> getRecentIngredientsLogs() {
        try {
            List<RecentLogsDTO> logs = machineDataService.getRecentIngredientsLogs();
            if (logs.isEmpty()) {
                return ResponseEntity.ok(Collections.emptyList());
            }
            return ResponseEntity.ok(logs);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Error fetching recent ingredients logs: " + e.getMessage());
        }
    }

    @GetMapping("/logs/{machineId}")
    public ResponseEntity<?> getMachineLogs(@PathVariable Long machineId) {
        try {
            return ResponseEntity.ok(coffeeMachineLogsService.getMachineLogs(machineId));
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error fetching machine logs: " + e.getMessage());
        }
    }
}
