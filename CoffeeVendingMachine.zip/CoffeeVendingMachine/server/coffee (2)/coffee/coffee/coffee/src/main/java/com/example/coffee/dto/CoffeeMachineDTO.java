package com.example.coffee.dto;

import com.example.coffee.entity.CoffeeMachineStatus;
import lombok.Data;

@Data
public class CoffeeMachineDTO {
    private Long coffeeMachineId;
    private String machineCode;
    private CoffeeMachineStatus status;
    private Long branchId;

    public CoffeeMachineDTO() {
    }
    public CoffeeMachineDTO(Long coffeeMachineId, String machineCode, CoffeeMachineStatus status, Long branchId) {
        this.coffeeMachineId = coffeeMachineId;
        this.machineCode = machineCode;
        this.status = status;
        this.branchId = branchId;
    }
    public Long getCoffeeMachineId() {
        return coffeeMachineId;
    }
    public void setCoffeeMachineId(Long coffeeMachineId) {
        this.coffeeMachineId = coffeeMachineId;
    }
    public String getMachineCode() {
        return machineCode;
    }
    public void setMachineCode(String machineCode) {
        this.machineCode = machineCode;
    }
    public CoffeeMachineStatus getStatus() {
        return status;
    }
    public void setStatus(CoffeeMachineStatus status) {
        this.status = status;
    }
    public Long getBranchId() {
        return branchId;
    }
    public void setBranchId(Long branchId) {
        this.branchId = branchId;
    }
}