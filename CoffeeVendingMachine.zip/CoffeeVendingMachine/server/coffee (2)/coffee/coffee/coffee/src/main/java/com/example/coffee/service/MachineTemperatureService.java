package com.example.coffee.service;
 
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.coffee.entity.MachineTemperature;
import com.example.coffee.dto.MachineTemperatureDTO;
import com.example.coffee.repository.MachineTemperatureRepository;
import com.example.coffee.service.CoffeeMachineService;
import java.time.LocalDateTime;
 
@Service
public class MachineTemperatureService {
    @Autowired
    private MachineTemperatureRepository machineTemperatureRepository;
 
    @Autowired
    private CoffeeMachineService coffeeMachineService;
 
    public MachineTemperatureDTO saveMachineTemperature(MachineTemperatureDTO dto) {
        try {
            if (dto.getCoffeeMachineId() == null) {
                throw new IllegalArgumentException("Coffee machine ID cannot be null");
            }

            MachineTemperature entity = convertToEntity(dto);
            
            // Set current time if recordedAt is not provided
            if (entity.getRecordedAt() == null) {
                entity.setRecordedAt(LocalDateTime.now());
            }

            entity = machineTemperatureRepository.save(entity);
            return convertToDTO(entity);
        } catch (Exception e) {
            throw new RuntimeException("Failed to save temperature data: " + e.getMessage());
        }
    }
 
    public List<MachineTemperatureDTO> getAllMachineTemperatures() {
        return machineTemperatureRepository.findAll()
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
 
    public List<MachineTemperatureDTO> getTemperaturesByMachineId(Long coffeeMachineId) {
        return machineTemperatureRepository.findByCoffeeMachineId(coffeeMachineId)
            .stream()
            .map(this::convertToDTO)
            .collect(Collectors.toList());
    }
 
    public MachineTemperatureDTO updateMachineTemperature(Long id, MachineTemperatureDTO dto) {
        MachineTemperature existingEntity = machineTemperatureRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("MachineTemperature not found with id: " + id));
 
        // Since temperature is primitive double, check for a sentinel value, e.g., negative value means no update
        if (dto.getTemperature() != 0.0) {
            existingEntity.setTemperature(dto.getTemperature());
        }
        if (dto.getType() != null) {
            existingEntity.setType(dto.getType());
        }
        if (dto.getCoffeeMachineId() != null) {
            existingEntity.setCoffeeMachine(coffeeMachineService.getCoffeeMachine(dto.getCoffeeMachineId()));
        }
 
        MachineTemperature updatedEntity = machineTemperatureRepository.save(existingEntity);
        return convertToDTO(updatedEntity);
    }
 
    private MachineTemperature convertToEntity(MachineTemperatureDTO dto) {
        try {
            MachineTemperature entity = new MachineTemperature();
            entity.setTemperature(dto.getTemperature());
            entity.setType(dto.getType());
            entity.setRecordedAt(dto.getRecordedAt() != null ? dto.getRecordedAt() : LocalDateTime.now());
            
            if (dto.getCoffeeMachineId() != null) {
                entity.setCoffeeMachine(coffeeMachineService.getCoffeeMachine(dto.getCoffeeMachineId()));
            }
            return entity;
        } catch (Exception e) {
            throw new RuntimeException("Error converting DTO to entity: " + e.getMessage());
        }
    }
 
    private MachineTemperatureDTO convertToDTO(MachineTemperature entity) {
        MachineTemperatureDTO dto = new MachineTemperatureDTO();
        dto.setTempId(entity.getTempId());
        dto.setTemperature(entity.getTemperature());
        dto.setType(entity.getType());
        dto.setRecordedAt(entity.getRecordedAt()); // Ensure recordedAt is copied
        if (entity.getCoffeeMachine() != null) {
            dto.setCoffeeMachineId(entity.getCoffeeMachine().getCoffeeMachineId());
        }
        return dto;
    }
}
