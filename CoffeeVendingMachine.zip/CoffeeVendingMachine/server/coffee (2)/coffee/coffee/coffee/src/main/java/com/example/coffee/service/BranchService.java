package com.example.coffee.service;

import com.example.coffee.entity.Branch;
import com.example.coffee.entity.Location;
import com.example.coffee.repository.BranchRepository;
import com.example.coffee.dto.BranchDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BranchService {
    @Autowired
    private BranchRepository branchRepository;
    
    @Autowired
    private LocationService locationService;

    public Branch createBranch(BranchDTO dto) {
        Location location = locationService.getLocation(dto.getLocationId());
        Branch branch = new Branch();
        branch.setName(dto.getName());
        branch.setLocation(location);
        return branchRepository.save(branch);
    }

    public List<Branch> getBranchesByLocation(Long locationId) {
        return branchRepository.findByLocationId(locationId);
    }

    public Branch getBranch(Long id) {
        return branchRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Branch not found"));
    }
}
