import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MonitoringForm from './components/MonitoringForm';

function App() {
  return (
    <Router>
      <Routes>
        // ...existing routes...
        <Route path="/monitoring" element={<MonitoringForm />} />
      </Routes>
    </Router>
  );
}

export default App;
