import axios from 'axios';

const BASE_URL = 'http://localhost:8082/api/iot';

export const sendTemperatureData = async (data) => {
  return await axios.post(`${BASE_URL}/temperature`, data);
};

export const sendIngredientsData = async (data) => {
  return await axios.post(`${BASE_URL}/ingredients`, data);
};
