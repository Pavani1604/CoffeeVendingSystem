import React, { useState } from 'react';
import axios from 'axios';

const MonitoringForm = () => {
  const [formData, setFormData] = useState({
    temperature: '',
    waterLevel: '',
    coffeePowder: '',
    milkLevel: '',
    teaPowder: '',
    sugarLevel: '',
    coffeeMachineId: '1',
    recordedAt: new Date().toISOString()
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      // Send temperature data
      await axios.post('http://localhost:8082/api/iot/temperature', {
        temperature: parseFloat(formData.temperature),
        coffeeMachineId: parseInt(formData.coffeeMachineId),
        recordedAt: formData.recordedAt,
        type: "1"
      });

      // Send ingredients data
      await axios.post('http://localhost:8082/api/iot/ingredients', {
        waterLevel: formData.waterLevel,
        coffeePowder: formData.coffeePowder,
        milkLevel: formData.milkLevel,
        teaPowder: formData.teaPowder,
        sugarLevel: formData.sugarLevel,
        coffeeMachineId: parseInt(formData.coffeeMachineId),
        recordedAt: formData.recordedAt,
        type: "2"
      });

      alert('Data sent successfully!');
    } catch (error) {
      console.error('Error sending data:', error);
      alert('Error sending data');
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="container mx-auto p-4">
      <h2 className="text-2xl font-bold mb-4">Coffee Machine Monitoring Form</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="form-group">
          <label className="block mb-1">Temperature (°C):</label>
          <input
            type="number"
            name="temperature"
            value={formData.temperature}
            onChange={handleChange}
            className="form-control border p-2 w-full"
            required
          />
        </div>

        <div className="form-group">
          <label className="block mb-1">Water Level (%):</label>
          <input
            type="text"
            name="waterLevel"
            value={formData.waterLevel}
            onChange={handleChange}
            className="form-control border p-2 w-full"
            required
          />
        </div>

        <div className="form-group">
          <label className="block mb-1">Coffee Powder (%):</label>
          <input
            type="text"
            name="coffeePowder"
            value={formData.coffeePowder}
            onChange={handleChange}
            className="form-control border p-2 w-full"
            required
          />
        </div>

        <div className="form-group">
          <label className="block mb-1">Milk Level (%):</label>
          <input
            type="text"
            name="milkLevel"
            value={formData.milkLevel}
            onChange={handleChange}
            className="form-control border p-2 w-full"
            required
          />
        </div>

        <div className="form-group">
          <label className="block mb-1">Tea Powder (%):</label>
          <input
            type="text"
            name="teaPowder"
            value={formData.teaPowder}
            onChange={handleChange}
            className="form-control border p-2 w-full"
            required
          />
        </div>

        <div className="form-group">
          <label className="block mb-1">Sugar Level (%):</label>
          <input
            type="text"
            name="sugarLevel"
            value={formData.sugarLevel}
            onChange={handleChange}
            className="form-control border p-2 w-full"
            required
          />
        </div>

        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Submit Data
        </button>
      </form>
    </div>
  );
};

export default MonitoringForm;
