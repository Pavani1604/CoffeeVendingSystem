import React, { useState, useEffect } from "react";
import axios from "axios";
import MachineMonitoringForm from "./MachineMonitoringForm";

function MachineAction({ branchId, onBack }) {
  const [machines, setMachines] = useState([]);
  const [error, setError] = useState("");
  const [selectedMachine, setSelectedMachine] = useState(null);

  // ...existing useEffect code...

  const handleFormClose = () => {
    setSelectedMachine(null);
  };

  return (
    <div style={{ maxWidth: "800px", margin: "0 auto" }}>
      <button
        onClick={onBack}
        style={{
          marginBottom: "10px",
          padding: "10px",
          backgroundColor: "#6c757d",
          color: "white",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer",
        }}
      >
        Back to Branches
      </button>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <h3>Available Machines</h3>
      <ul style={{ listStyle: "none", padding: 0 }}>
        {machines.map((machine) => (
          <li
            key={machine.coffeeMachineId}
            style={{
              padding: "15px",
              margin: "10px 0",
              backgroundColor: "#f4f4f9",
              border: "1px solid #ccc",
              borderRadius: "4px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span>{machine.machineCode}</span>
              <button
                onClick={() => setSelectedMachine(machine)}
                style={{
                  padding: "8px 15px",
                  backgroundColor: "#007bff",
                  color: "white",
                  border: "none",
                  borderRadius: "4px",
                  cursor: "pointer",
                }}
              >
                Monitor Machine
              </button>
            </div>
            {selectedMachine?.coffeeMachineId === machine.coffeeMachineId && (
              <MachineMonitoringForm
                machine={machine}
                onClose={handleFormClose}
              />
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MachineAction;
