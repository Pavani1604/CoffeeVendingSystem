import React, { useState } from 'react';
import axios from 'axios';

const MachineMonitoringForm = ({ machine, onClose }) => {
  const [formData, setFormData] = useState({
    temperature: '',
    waterLevel: '',
    coffeePowder: '',
    milkLevel: '',
    teaPowder: '',
    sugarLevel: '',
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const timestamp = new Date().toISOString();

    try {
      // Send temperature data
      await axios.post('http://localhost:8082/api/iot/temperature', {
        temperature: parseFloat(formData.temperature),
        coffeeMachineId: machine.coffeeMachineId,
        recordedAt: timestamp,
        type: "1"
      });

      // Send ingredients data
      await axios.post('http://localhost:8082/api/iot/ingredients', {
        waterLevel: formData.waterLevel,
        coffeePowder: formData.coffeePowder,
        milkLevel: formData.milkLevel,
        teaPowder: formData.teaPowder,
        sugarLevel: formData.sugarLevel,
        coffeeMachineId: machine.coffeeMachineId,
        recordedAt: timestamp,
        type: "2"
      });

      alert('Data sent successfully!');
      setFormData({
        temperature: '',
        waterLevel: '',
        coffeePowder: '',
        milkLevel: '',
        teaPowder: '',
        sugarLevel: '',
      });
    } catch (error) {
      console.error('Error sending data:', error);
      alert('Error sending data: ' + error.message);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div style={{ marginTop: "20px", padding: "15px", backgroundColor: "white", borderRadius: "4px" }}>
      <h4>Monitor Machine: {machine.machineCode}</h4>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Temperature (°C):</label>
          <input
            type="number"
            name="temperature"
            value={formData.temperature}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            required
          />
        </div>

        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Water Level (%):</label>
          <input
            type="text"
            name="waterLevel"
            value={formData.waterLevel}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            required
          />
        </div>

        {/* Add similar input fields for other ingredients */}
        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Coffee Powder (%):</label>
          <input
            type="text"
            name="coffeePowder"
            value={formData.coffeePowder}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            required
          />
        </div>

        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Milk Level (%):</label>
          <input
            type="text"
            name="milkLevel"
            value={formData.milkLevel}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            required
          />
        </div>

        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Tea Powder (%):</label>
          <input
            type="text"
            name="teaPowder"
            value={formData.teaPowder}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            required
          />
        </div>

        <div style={{ marginBottom: "15px" }}>
          <label style={{ display: "block", marginBottom: "5px" }}>Sugar Level (%):</label>
          <input
            type="text"
            name="sugarLevel"
            value={formData.sugarLevel}
            onChange={handleChange}
            style={{ width: "100%", padding: "8px", borderRadius: "4px", border: "1px solid #ddd" }}
            required
          />
        </div>

        <div style={{ display: "flex", gap: "10px" }}>
          <button
            type="submit"
            style={{
              padding: "10px 20px",
              backgroundColor: "#28a745",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Submit
          </button>
          <button
            type="button"
            onClick={onClose}
            style={{
              padding: "10px 20px",
              backgroundColor: "#dc3545",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer",
            }}
          >
            Close
          </button>
        </div>
      </form>
    </div>
  );
};

export default MachineMonitoringForm;
