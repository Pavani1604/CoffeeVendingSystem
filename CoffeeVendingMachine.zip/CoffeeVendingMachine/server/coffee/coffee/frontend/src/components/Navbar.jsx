import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav>
      // ...existing nav items...
      <Link to="/monitoring" className="nav-link">
        Machine Monitoring
      </Link>
    </nav>
  );
};
